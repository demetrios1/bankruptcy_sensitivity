##packages##
library(data.table)
library(randomForest)
#install.packages('dbarts')
library(dbarts)
library(readr)
library(dplyr)
library(tidyverse)
library(foreach)
library(bcf)
library(fastbart)
#library(GJRM)
print('to avoid error message')
monotone_bart = function(y, z, x, xpred, nskip=5000, ndpost=5000, m = 50, n=N) {
  
  sort_ix = order(z, y)
  x = x[sort_ix,]
  z = z[sort_ix]
  y = y[sort_ix]
  
  n0 = sum(z==0)
  n00 = sum(z==0 & y==0)
  yobs = y
  yobs0 = rbinom(n, 1, 0.5)
  yobs[1:n00] = rbinom(n00, 1, 0.5) # These are DA variables
  yobs0[1:n00] = rbinom(n00, 1, 0.5) # These are DA variables
  yobs0[1:n00][yobs[1:n00]==1] = 0 # To statisfy DA constraints
  yobs0[z==0 & y==1] = 1
  yobs0 = yobs0[1:n0] 
  
  offset =  0#qnorm(mean(y[z==1]))
  offset0 = 0# qnorm(mean(flu$grp==0 & flu$fluy2==1)/mean(flu$grp==1 & flu$fluy2==1)) #<- wtf
  
  zz = offset + 3*yobs - 3*(1-yobs)
  z0 = offset0 + 3*yobs0 - 3*(1-yobs0)
  
  ################################################################################
  # MCMC
  ################################################################################
  
  set.seed(1022)
  
  xi = lapply(1:ncol(x), function(i) bcf:::.cp_quantile(x[,i]))
  fit.mono = bartRcppMono(yobs, zz, t(as.matrix(x)), t(xpred),
                          yobs0, z0, t(as.matrix(x)),t(xpred),
                          n00,
                          xi,
                          nskip, ndpost, m, 3.0,
                          offset, offset0)
  
  #xpred.exp = rbind(data.frame(xpred, z=1), data.frame(xpred, z=0))
  #fit =  bart(cbind(x, z), y, xpred.exp,
  #               nskip=5000, ndpost=5000,
  #               ntree=50, usequants=T)
  
  
  # P(Y|Z=1, X)
  pr1 = pnorm(fit.mono$postpred)
  
  # P(Y|Z=0, X)
  pr0 = pr1*pnorm(fit.mono$postpred0)
  
  return(list(pr0 = pr0, pr1 = pr1))
  
}

BARTpred=function(df, treat=G, Outcome=B,vars){
  covtreat=df%>%filter(treat==1)
  covcontrol=df%>%filter(treat==0)
  covtreat$treat=as.factor(covtreat$treat)
  
  #return(df[vars])
  #return(as.factor(covtreat$outcome))
  #case 1, the treatment
  # bart1=bart(covtreat[vars],as.factor(covtreat$B), df[vars],ndpost = 5000, nskip = 2000,ntree=100,verbose=F,usequants = TRUE,numcut = 1000)
  
  #case 2 control
  #bart2=bart(covcontrol[vars],as.factor(covcontrol$B),df[vars],ndpost =5000, nskip = 2000,ntree=100,verbose=F,usequants = TRUE,numcut = 1000)
  
  #case 3 propensity
  bart3=bart(df[vars], as.factor(df$treat),df[vars],ndpost = 5000, nskip = 2000,ntree=100,verbose=F,usequants = TRUE,numcut = 1000)
  
  
  xtest=df[vars]
  xtraincontrol=covcontrol[vars]
  xtraintreat=covtreat[vars]
  ytrain0    = as.factor( covcontrol$outcome.Y )
  ytrain1    = as.factor( covtreat$outcome.Y )
  
  # mono fits
  
  bart_mono = monotone_bart(y = as.numeric(c(ytrain1, ytrain0)==1),
                            z = 1-c(rep(1, length(ytrain1)), rep(0, length(ytrain0))),
                            x = rbind(xtraintreat, xtraincontrol),
                            xpred = xtest, nskip = 2000, ndpost = 5000,m=100)
  
  
  
  #bart3 = bart(df[vars], as.factor(df$G),df[vars], ndpost = 5000, nskip = 2000, ntree=100, usequants=T, numcuts=1000, verbose=F)
  
  
  
  #use this method for prediction on binary
  #pred1 = colMeans(pnorm(bart1$yhat.test)) 
  #pred2=colMeans(pnorm(bart2$yhat.test))
  pred1= 1-colMeans(bart_mono$pr0)
  pred2= 1-colMeans(bart_mono$pr1)
  pred3=colMeans(pnorm(bart3$yhat.test))
  
  #pred1 = colMeans(pnorm(bart1$yhat.test)) 
  #pred2=colMeans(pnorm(bart2$yhat.test))
  
  
  
  
  expoutcomesfun	   =cbind( df[,], data.frame(  treatpred = pred1, notreatpred=pred2), propensity=pred3 )
  
  expoutcomesfun2    = rbind( NULL, expoutcomesfun )
  outcomenew=expoutcomesfun2[,c('propensity','notreatpred','treatpred')]
  
  
  ####need the joints####
  
  eps     = 1e-6
  
  outcomenew[,c("prop", "Y_D0", "Y_D1")] = 0.5*eps + (1-eps)*outcomenew[,c('propensity','notreatpred','treatpred')]
  
  outcomenew[,"ProbY1D1"]=outcomenew[,"prop"]*outcomenew[,"treatpred"]
  outcomenew[,"ProbY1D0"] = (1-outcomenew[,"prop"])*outcomenew[,"notreatpred"]
  outcomenew[,"ProbY0D1"] = outcomenew[,"prop"]*(1-outcomenew[,"treatpred"])
  
  #for error analysis, not super necessary
  indexes=seq(from=1, to=length(outcomenew$treatpred), by=1)
  outcomenew=as.data.frame(cbind(indexes, outcomenew))
  outcomenew$indexes=as.numeric(outcomenew$indexes)
  row.names(outcomenew)<-NULL
  newoutcome4 =as.matrix(outcomenew)
  return(outcomenew)
}
####init####
set.seed(12345)
#make bigger later
N=5000
n = 5000
#### covariates####

#categoricals, bernoulli or binomial
x1=rbinom(n,1,.1)
x2 = rbinom(n,1,0.25)
x3 = rbinom(n,1,0.5)
x4=rbinom(n,1,.7)
x5=rbinom(n,2,.2)
#continuous variables, just using uniform
x6 = runif(n,0,1)
x7=runif(n,2,4)
x8=runif(n,-1,3)
epsy = rnorm(n)

# exogenous variables
x1=rbinom(n,1, .1)
x2 = rbinom(n,1,0.25)
x3 = rbinom(n,1,0.5)
x4=rbinom(n,1, .75)
x5 =  1 + 2*rnorm(n)
x6=rnorm(n,2,1)
x7=rnorm(n, 0,.3)
x8=2-.5*rnorm(n)
epsy = rnorm(n)


####confounding on D and Y (private info analogue for audits)####
#can run this for various U's
ufun=function(mean1, sd1){
  return(rnorm(n, mean=mean1, sd=sd1))
}
strangeU=function(meanlist, sdlist, j){
  mean1=meanlist[1]
  sd1=sdlist[1]
  mean2=meanlist[2]
  sd2=sdlist[2]
  return((j/10)*rnorm(n, mean=mean1, sd=sd1)+(1-((2*(j))/10))*rnorm(n, mean=0, sd=1)+(j/10)*rnorm(n, mean=mean2, sd=sd2))
}

means=c(-1,1)
sds=c(.5, .5,.5)
j=.9
treat_list<-c()
tau_est_list<-c()
naive_list<-c()
treat_list_bart<-c()
tau_est_list_bart<-c()
naive_list_bart<-c()
prob_treat<-c()
true_loc_ecdf<-c()
#sanity check
#globally define the marginal distribution of U that we integrate over
meanu=c(rep(c(-3,-2,-1,0,1,2,3), 2))
std=c(1,1,1,0.1,1,1,1,rep(0.5, 7))
for (i in 1:1){#length(meanu)){
  
  
  f=function(u){
    dnorm(u, mean=meanu[[i]], sd=std[[i]])
  }
  
  #change these together
  U<-c()
  U[[i]]=ufun(meanu[i],std[i])
  
  
  #U[[i]]=strangeU(means, sds, j)
  
  ####treatment variable####
  
  b1=function(x1,x2,x3,x4,x5,x6,x7,x8){
    val=sin(x1) -2*x2 +1.5*x3*x4-2*cos(x5)+ 1.2*(x6>0)  -2.7*(x7>0)+2.5*(x8<0)
    return(pnorm(val))
  }
  g_func=function(x1,x2,x3,x4,x5,x6,x7,x8){
    val=cos(x1) +2*x2 -1.5*x3*x4-1.2*sin(x5)+ 1.2*(x6>0)  -2.4*(x7>0)+2.1*(x8<0)
    return(pnorm(val))
  }
  g=g_func(x1,x2,x3,x4,x5,x6,x7,x8)
  p=.25
  D=function(U, epsy){
    #val =  x1 -2*x2 +1.5*x3-.5*x4+2*x5+ x6  -0.7*x7+2.2*x8+U
    val= g+U +0*epsy #end is random noise
    #val=p+U  #keep this constant, o.w. we can't control for exogenous variables
    #we assume in analysis that we can
    return(rbinom(n,1,pnorm(val)))
  }

  treat=D(U[[i]], epsy)
  prob_treat[[i]]=sum(treat)/n
  
  
  
  
  ####Outcome Variable####
  Y=function(U,D, epsy){
    val = b1(x1,x2,x3,x4,x5,x6,x7,x8) +U+D+epsy  #end is random noise
    return(data.frame(Y=rbinom(n,1,pnorm(val)), value=val))
  }
  
  outcome=Y(U[[i]],treat, epsy)
  
  outcome_prob=pnorm(outcome$value)
  
  ##for the potential outcomes
  #this creates our treatment
  propensityfun=function(U, epsy){
    #calculating probablity of being in treatment regime
    #val = pnorm(p+U)  #homogenous treatment effect for now...
    val= pnorm(g+U +0*epsy) #end is random noise
    #o.w.#treat_cov+U+0*epsy)#
    return(val)
  }
  
  
  
  
  potoutcomes=data.frame(Y1=pnorm(Y(U[[i]],1, epsy)$value),
                         Y0=pnorm(Y(U[[i]],0, epsy)$value),
                         obs=pnorm(Y(U[[i]],treat, epsy)$value), treat)
  
  colnames(potoutcomes)=c('Y1','Y0', 'observed', 'treat')
  potoutcomes=potoutcomes%>%
    mutate(outcomediff=Y1-Y0)
  
  
  potoutcomes%>%
    ggplot(aes(x=outcomediff))+geom_histogram(aes(y=..count../sum(..count..)),fill='dodgerblue4', color='white')
  length(potoutcomes$outcomediff)
  #treateffect=
  # foreach( i = 1:1000,  .combine=rbind )%dopar%{
  #integrate( function(u) potoutcomes$outcomediff*f(u), lower = -Inf, upper = Inf )$value
  # }
  treateffect=c()
  
  for (k in 1:length(potoutcomes$outcomediff)){
    treateffect[[k]]=integrate( function(u) potoutcomes$outcomediff[[k]]*dnorm(u, mean=meanu[[i]], sd=std[[i]]), lower = -Inf, upper = Inf )$value  
  }
  potoutcomes$outcomediff
  as.data.frame(treateffect)%>%
    summarize(mean(treateffect))
  #ggplot(aes(x=treateffect))+geom_histogram()
  #these two numbers should be the same!!!!
  actual_way1=mean(treateffect)
  actual_way2=mean(potoutcomes$Y1-potoutcomes$Y0)
  
  #naive estimate is way bigger!
  naive_est=mean(potoutcomes[potoutcomes[, 'treat']==1,'observed'])-mean(potoutcomes[potoutcomes[, 'treat']==0,'observed'])
  data.frame(actual_way1, actual_way2, naive_est)
  
  
  ####eps is to avoid 0's, bad computationally, want P!=0 or P!=1####
  eps     = 1e-6
  probY1D1=0.5*eps + (1-eps)*potoutcomes[potoutcomes[, 'treat']==1,'observed']
  probY1D0=0.5*eps + (1-eps)*potoutcomes[potoutcomes[, 'treat']==0,'observed']
  probD1=0.5*eps + (1-eps)*propensityfun(U[[i]], epsy)#potoutcomes[, 'treat']
  
  #mean(probD1) should be close to sum(treat)/n
  #convert to the joint probabilities
  ProbY1D1=probD1*probY1D1
  ProbY1D0=(1-probD1)*probY1D0
  ProbY0D1=probD1*(1-probY1D1)
  intframe=data.frame(cbind(ProbY1D1,ProbY1D0, ProbY0D1))
  indexes=seq(from=1, to=length(intframe$ProbY1D1), by=1)
  intframe=as.data.frame(cbind(indexes, intframe))
  
  covariates=data.frame(x1,x2,x3,x4,x5,x6,x7,x8, epsy,outcome$Y, treat)
  vars=c('x1','x2','x3','x4','x5','x6','x7','x8', 'epsy')
  intframe=BARTpred(covariates, treat=treat, Outcome=outcome$Y,vars)
  #covariates=data.frame(x1,x2,x3,x4,x5,x6,x7,x8, epsy,outcome$Y, treat)
  #vars=c('x1','x2','x3','x4','x5','x6','x7','x8', 'epsy')
  #intframe=BARTpred(covariates, treat=treat, Outcome=outcome$Y,vars)
  
  
  ##Simulation for Audit code##
  library(foreach)
  library(doParallel)
  
  #np = 7
  #cl = makeCluster(np)
  n_cores <- detectCores() - 1
  registerDoParallel(cores = n_cores)
  #registerDoParallel(cl)
  
  newoutcome=as.matrix(intframe)
  
  
  
  
  
  f=function(u){
    dnorm(u, mean=meanu[[i]], sd=std[[i]])
  }
  
  
  # f=function(u){
  #   .04*dnorm(u, mean=-2, sd=0.05)+0.95*dnorm(u,mean=0,sd=0.05)+.01*dnorm(u,mean=2,sd=0.05)
  #  }
  
  print( sd )
  ptm = proc.time()
  
  mBG_out = foreach( m = 1:dim(newoutcome)[1],  .combine=rbind )%dopar%{
    # Probability to fit.
    vProbBG     = newoutcome[m,c( "ProbY1D1", "ProbY1D0", "ProbY0D1" )] 
    
    
    # Starting value
    
    start0 = c( newoutcome[m,"ProbY1D1"], newoutcome[m,"ProbY1D0"],newoutcome[m,"ProbY0D1"] )
    
    names(start0) = c("y1","y0","d")
    
    
    #better global definition.
    optimdist=function(vals){
      y1 = vals[1]
      y0 = vals[2]
      d = vals[3]
      a=integrate( function(u) pnorm(y1+u)*pnorm(d+u)*f(u), lower = -Inf, upper = Inf )$value
      b=integrate(function(u) pnorm(y0+u)*(1-pnorm(d+u))*f(u), lower = -Inf, upper = Inf )$value
      c=integrate(  function(u) (1-pnorm(y1+u))*pnorm(d+u)*f(u), lower = -Inf, upper = Inf )$value 
      #return(c(a,b,c))
      return(sum((qnorm(c(a,b,c))-qnorm(vProbBG))^2))
    }
    
    #calculate the treatment
    treatment_Compute = function( vb){
      integrate( function(u) (pnorm(vb[1]+u) - pnorm(vb[2]+u))*f(u), lower = -Inf, upper = Inf )$value
      
    }
    
    counterfac_Compute = function(vb){
      y1 =(integrate( function(u) (pnorm(vb[1]+u))*f(u), lower = -Inf, upper = Inf )$value)
      y0 = (integrate( function(u) (pnorm(vb[2]+u))*f(u), lower = -Inf, upper = Inf )$value)
      
      return(c(y1, y0))
      
    }
    vBG_out     = try(optim( qnorm(start0), optimdist,  control = list(abstol = 1e-16, maxit = 150) )	
                      , silent=TRUE)
    if ( class( vBG_out ) == "try-error" ){
      out        = as.numeric(newoutcome[m,c("indexes")])
      out        = c( out, rep(NA,5) ) 
    } else {
      out        = as.numeric(newoutcome[m,c("indexes")] )
      vBG        = vBG_out$par 
      tau      = treatment_Compute( vb = vBG[c(1,2)])
      
      counter=counterfac_Compute(vb = vBG[c(1,2)])
      
      out        = c( vBG, tau,vBG_out$convergence, vBG_out$value,counter) 
    }
    return( out)
  }
  
  print( proc.time() - ptm )
  dim(mBG_out)
  
  
  
  colnames(mBG_out) = c( "y1", "y0", "d", "tau", "convergence", "fnvalue" ,'B1','B0')
  as.data.frame(mBG_out)%>%
    summarize(mean(tau,na.rm=T))
  true_loc_ecdf[[i]]=ecdf(data.frame(mBG_out)$tau)(actual_way1)
  tau_est=mean(mBG_out[, 'tau'], na.rm=T)
  as.data.frame(mBG_out)%>%
    ggplot(aes(x=tau))+geom_histogram(aes(y=..count../sum(..count..)),fill='dodgerblue4', color='white')
  print(paste0('true treatment: ', round(actual_way1,3), ' our estimate: ', round(tau_est,3 )))
 
  treat_list[[i]]<-actual_way1
  tau_est_list[[i]]<-tau_est
  
  naive_list[[i]]<-naive_est
  print(i)
}

library(stargazer)
#write.csv(data.frame( meanu, std, prob_treat,true_loc_ecdf,tau_est_list,treat_list, naive_list ), 'audit_nonlinsim.csv')
View(data.frame( meanu, std, prob_treat,true_loc_ecdf,tau_est_list,treat_list, naive_list ))
library(xtable)
xtable(data.frame( meanu, std, prob_treat,true_loc_ecdf,tau_est_list,treat_list, naive_list ))
#stargazer(t(data.frame( meanu, std, prob_treat,true_loc_ecdf,tau_est_list,treat_list, naive_list )))

RMSE <- function(m, o){
  sqrt(mean((m - o)^2))
}
RMSE(unlist(tau_est_list), unlist(treat_list))
mean(treateffect)
mean(mBG_out[, 'tau'])
plot( treateffect,mBG_out[, 'tau'])
abline(0,1, col='red')



