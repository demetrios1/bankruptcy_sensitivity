library(MASS)
library(tidyverse)
####now look using BART####
library(dplyr)
library(dbarts)

BARTpred=function(df, treat=G, Outcome=B,vars){
  covtreat=df%>%filter(G==1)
  covcontrol=df%>%filter(G==0)
  covtreat$G=as.factor(covtreat$G)
  #return(df[vars])
  #return(as.factor(covtreat$outcome))
  #case 1, the treatment
  bart1=bart(covtreat[vars],as.factor(covtreat$B), df[vars],ndpost = 5000, nskip = 2000,ntree=150,verbose=F)
  
  #case 2 control
  bart2=bart(covcontrol[vars],as.factor(covcontrol$B),df[vars],ndpost =5000, nskip = 2000,ntree=150,verbose=F)
  
  #case 3 propensity
  bart3=bart(df[vars], as.factor(df$G),df[vars],ndpost = 5000, nskip = 2000,ntree=150,verbose=F)

  #use this method for prediction on binary
  pred1 = colMeans(pnorm(bart1$yhat.test)) 
  pred2=colMeans(pnorm(bart2$yhat.test))
  pred3=colMeans(pnorm(bart3$yhat.test))
  
  

  
  
  
  expoutcomesfun	   =cbind( df[,], data.frame(  treatpred = pred1, notreatpred=pred2), propensity=pred3 )
  
  expoutcomesfun2    = rbind( NULL, expoutcomesfun )
  outcomenew=expoutcomesfun2[,c('propensity','notreatpred','treatpred')]
  
  
  ####need the joints####
  
  eps     = 1e-6
  
  outcomenew[,c("prop", "Y_D0", "Y_D1")] = 0.5*eps + (1-eps)*outcomenew[,c('propensity','notreatpred','treatpred')]
  
  outcomenew[,"ProbY1D1"]=outcomenew[,"prop"]*outcomenew[,"treatpred"]
  outcomenew[,"ProbY1D0"] = (1-outcomenew[,"prop"])*outcomenew[,"notreatpred"]
  outcomenew[,"ProbY0D1"] = outcomenew[,"prop"]*(1-outcomenew[,"treatpred"])
  
  #for error analysis, not super necessary
  indexes=seq(from=1, to=length(outcomenew$treatpred), by=1)
  outcomenew=as.data.frame(cbind(indexes, outcomenew))
  outcomenew$indexes=as.numeric(outcomenew$indexes)
  row.names(outcomenew)<-NULL
  newoutcome4 =as.matrix(outcomenew)
  return(outcomenew)
}



#intframe=intframe%>%select(indexes, ProbY1D1, ProbY1D0, ProbY0D1)

##Simulation for Audit code##

library(foreach)
library(doParallel)
####helper functions####

np = detectCores()-1
cl = makeCluster(np)
n_cores <- detectCores() - 1
registerDoParallel(cores = n_cores)





mBG_out<-c()
rho_list<-c(rep(0.1, 5), rep(0.4, 5), rep(0.6, 5), rep(0.8,5), 0.6)
gamma_list<-c(rep(seq(from=0.1, to=0.5, length.out=5), 4), .7)
for (m in 1){#length(gamma_list)){
  N <- 1000 # Number of random samples
  #set.seed(123) #for variation in the x's
  # Target parameters for univariate normal distributions
  x1=runif(N, -1,1)
  x2=runif(N, -1,1)
  x3=runif(N,-1,1)
  x4=runif(N,-1,1)
  x5=runif(N, -1,1)
  
  beta1=-.8
  alpha1=0.6
  beta0=-1.2
  alpha0=-1
  mu1 <- beta0+beta1*(x1+x2+x3+x4+x5)
  mu2 <- alpha0+alpha1*(x1+x2+x3+x4+x5)
  
  mu<-matrix(c(mu1, mu2), nrow=N, ncol=2)

  gamma=gamma_list[[m]]
  sigma <- matrix(c(1, rho^2,rho^2,1),
                  2) # Covariance matrix
  
  f=function(u){
    dnorm(u, mean=0, sd=rho)#(1-rho^2)^2)
  }
  sim_data=t(sapply(1:N, function(i)mvrnorm(1, mu = mu[i,], Sigma = sigma )))
  #sim_data=mvrnorm(N, c(-1.6,-2.6), sigma)
  G=sapply(1:N, function(i)ifelse(sim_data[i,1]>=0, 1,0))
  
  
  B=sapply(1:N, function(i)ifelse(sim_data[i,2]>=-1*gamma*G[i], 1,0))
  
  covariates=data.frame(x1,x2,x3,x4,x5,B, G)
  
  vars=c('x1','x2','x3','x4','x5')
  intframe=BARTpred(covariates, treat=G, Outcome=B,vars)

  library(truncnorm)
  pB.G1 = sapply(1:N, function(j) mean(pnorm(mu2[j] + rho*rtruncnorm(10000,0,+Inf,mu1[j]) + gamma)))
  pB.G0=pnorm(mu2)
  #plot(pB.G1, intframe$Y_D1)
#cor(pB.G1, intframe$Y_D1)
#cor(pnorm(mu2), intframe$Y_D0)
 # plot(pnorm(mu2), intframe$Y_D0)
  newoutcome=as.matrix(intframe)
  
  ptm = proc.time()
  
  mBG_out[[m]] = foreach( i = 1:dim(newoutcome)[1],  .combine=rbind )%dopar%{
    # Probability to fit.
    vProbBG     = newoutcome[i,c( "ProbY1D1", "ProbY1D0", "ProbY0D1" )] 
    
    
    # Starting value
    
    start0 = c( newoutcome[i,"ProbY1D1"], newoutcome[i,"ProbY1D0"],newoutcome[i,"ProbY0D1"] )
    
    names(start0) = c("y1","y0","d")
    
    
    
    #better global definition.
    optimdist=function(vals){
      y1 = vals[1]
      y0 = vals[2]
      d = vals[3]
      a=integrate( function(u) pnorm(y1+u)*pnorm(d+u)*f(u), lower = -Inf, upper = Inf )$value
      b=integrate(function(u) pnorm(y0+u)*(1-pnorm(d+u))*f(u), lower = -Inf, upper = Inf )$value
      c=integrate(  function(u) (1-pnorm(y1+u))*pnorm(d+u)*f(u), lower = -Inf, upper = Inf )$value 
      #return(c(a,b,c))
      return(sum((qnorm(c(a,b,c))-qnorm(vProbBG))^2))
    }
    
    #calculate the treatment
    treatment_Compute = function( vb){
      integrate( function(u) (pnorm(vb[1]+u) - pnorm(vb[2]+u))*f(u), lower = -Inf, upper = Inf )$value
      
    }
    
    counterfac_Compute = function(vb){
      y1 =(integrate( function(u) (pnorm(vb[1]+u))*f(u), lower = -Inf, upper = Inf )$value)
      y0 = (integrate( function(u) (pnorm(vb[2]+u))*f(u), lower = -Inf, upper = Inf )$value)
      
      return(c(y1, y0))
      
    }
    vBG_out     = try(optim( qnorm(start0), optimdist,  control = list(abstol = 1e-16, maxit = 150) )	
                      , silent=TRUE)
    if ( class( vBG_out ) == "try-error" ){
      out        = as.numeric(newoutcome[i,c("indexes")])
      out        = c( out, rep(NA,5) ) 
    } else {
      out        = as.numeric(newoutcome[i,c("indexes")] )
      vBG        = vBG_out$par 
      tau      = treatment_Compute( vb = vBG[c(1,2)])
      
      counter=counterfac_Compute(vb = vBG[c(1,2)])
      
      out        = c( vBG, tau,vBG_out$convergence, vBG_out$value,counter) 
    }
    return( out)
  }
  
  print( proc.time() - ptm )
  
  colnames(mBG_out[[m]]) = c( "y1", "y0", "d", "tau", "convergence", "fnvalue" ,'B1','B0')
  print(m)
}

as.data.frame(mBG_out[[1]])%>%
  summarize(mean(tau,na.rm=T))
pnorm(mu2)
library(splines)
fit=lm(mBG_out[[1]][, 'B1']~ bs(mBG_out[[1]][, 'B0'],3))
summary(fit)
plot(mBG_out[[1]][, 'B0'], pnorm(mu2))
plot(mBG_out[[1]][, 'B1'], pnorm(mu2+gamma))
plot(pnorm(mu2),pnorm(mu2+gamma))
points(mBG_out[[1]][, 'B0'], mBG_out[[1]][, 'B1'], col='red')
points(mBG_out[[1]][, 'B0'],fit$fitted.values, col='green')

estimate=fit$fitted.values-mBG_out[[1]][, 'B0']

plot(estimate,ATE_true, xlim=c(0, .1))
abline(0,1,col='red')

our_ATE=mBG_out[[1]][, 'B1']-mBG_out[[1]][, 'B0']
ATE_true=pnorm(mu2+gamma)-pnorm(mu2)
plot(mu2,ATE_true-our_ATE)



plot(mBG_out[[3]][, 'B1'], pnorm(mu2+gamma))
plot(mBG_out[[3]][, 'B1'][pnorm(mu2+gamma)>0.1]-mBG_out[[3]][, 'B0'][pnorm(mu2+gamma)>0.1], pnorm(mu2+gamma)[pnorm(mu2+gamma)>0.1]-pnorm(mu2)[pnorm(mu2+gamma)>0.1])
pnorm(gamma)
max(pnorm(mu2+gamma)-pnorm(mu2))
abline(0,1, col='r')

as.data.frame(mBG_out[[2]])%>%
  ggplot(aes(x=tau))+geom_histogram(aes(y=..count../sum(..count..)),fill='dodgerblue4', color='white')+
  geom_vline(aes(xintercept=gamma))

tau_mean<-sapply(1:length(gamma_list), function(i)mean(mBG_out[[i]][,'tau']))

data.frame(tau_mean, gamma_list, rho_list)

