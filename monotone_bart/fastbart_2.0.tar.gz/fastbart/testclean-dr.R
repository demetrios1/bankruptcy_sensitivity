library(fastbart)
library(mclust)
set.seed(10)
n=400
x = runif(n)
x2 = as.numeric(runif(n)>0.5)
f = function(x, x2) 3*x + (2-4*x2)*sin(pi*x)
y = f(x, x2) + log(rgamma(n, 2, 1 + 3*x))
ybar = 0#mean(y)
y = y-ybar


mid = 0.8
p = function(x, h=0.05) 0.9*exp(-abs(x-mid)^2/h)
#mu0 = function(x) 12*(x-0.4)^2 - 5*exp(15*(x-0.8))/(1+exp(15*(x-0.8)))
mu0 = function(x) 5*exp(15*(x-.5))/(1+exp(15*(x-.5))) - 4*x
m1 = function(x) 1-1*(x-mid)
s1 = function(x) 0.35
a2 = function(x) 0.5+2*x
b2 = function(x) 1#0.5*exp(0.5*(x-mid))
f1 = function(y, x) dnorm(y, mu0(x) + m1(x), s1(x))
F1 = function(y, x) pnorm(y, mu0(x) + m1(x), s1(x))
f2 = function(y, x) dgamma(exp(y-mu0(x)), a2(x), b2(x))*exp(y-mu0(x))#dnorm(y, 2*sqrt(x), 2*x^2+1)
F2 = function(y, x) pgamma(exp(y-mu0(x)), a2(x), b2(x))
d = function(y, x) { p = p(x); p*f1(y, x) + (1-p)*f2(y, x) }
pp = function(y, x) { p = p(x); p*F1(y, x) + (1-p)*F2(y, x) }
r = function(x) {
  n = length(x)
  z = rbinom(n, 1, p(x))
  z*rnorm(n, m1(x), s1(x)) + (1-z)*log(rgamma(n, a2(x), b2(x))) + mu0(x)
}

y = r(x)


df = data.frame(x,x2,y)
lmf = lm(y~.,df)
resids = resid(lmf)

sighat = summary(lmf)$sigma

nu=3
sigq = .9
qchi = qchisq(1.0-sigq,nu)
lambda = (sighat*sighat*qchi)/nu 

xpred = cbind( rep((1:99)/100, 2), c(rep(0, 99), c(rep(1,99))))

set.seed(5346)
#u = runif(n)
u = rep(1/2, n)
xx = cbind(u, x, x2)
fit = drbartRcppClean(y, t(xx), #D,#[,-2,drop=F],
                    t(xpred), #Dpred,#[,-2,drop=F],
                    list((1:99999)/100000, (1:999)/1000, c(0, 0.5, 1.0)), 
                    1500, 2000, 200, 
                    lambda, nu, 3,
                    rep(0, length(y)),
                    "/Users/jared/Desktop/test.txt"
                    )
#stop()
ts = TreeSamples$new()
ts$load('/Users/jared/Desktop/test.txt')
#insam = ts$predict(t(xx))

pprobs = lapply(fit$ucuts, function(uu) diff(c(0, uu, 1)))
pmids = lapply(fit$ucuts, function(uu) c(0,uu)+diff(c(0, uu, 1))/2)
#pxpred = lapply(mids, function(uu) data.frame(uu, x=0.1, x2=0))

uu = sort(unique(unlist(fit$ucuts)))
probs = diff(c(0, uu, 1))
mids = c(0,uu)+diff(c(0, uu, 1))/2


x = 0.8; x2 = 0

xx=seq(-5, 9, length.out=1000)
#y = dmixnorm0(xx, log(probs), mu[1000,], fit$sigma[1000])
#plot(xx, exp(y))

logprobs = lapply(fit$ucuts, function(uu) log(diff(c(0, uu, 1))))
mids = lapply(fit$ucuts, function(uu) c(0,uu)+diff(c(0, uu, 1))/2)
des = lapply(mids, function(mm) data.frame(mm, x, x2))
mu = lapply(1:2000, function(i) c(ts$predict_i(t(des[[i]]), i-1)))

dpost = dmixnorm0_post(xx, mu, fit$sigma, logprobs)

plot(xx, apply(exp(dpost), 1, mean), type='l')
matplot(xx, t(apply(exp(dpost), 1, quantile, c(0.05, 0.95))), lty=2, col='black', type='l', add=TRUE)
#lines(xx, dnorm(xx, f(x, x2), 0.15 + .2*x), lty=2)
#lines(xx, f(xx, x2) + dgamma(xx, 1.1, 0.15 + 3*x), lty=2)
yy = f(x, x2) + log(rgamma(1e7, 2, 1 + 3*x))
lines(density(yy), col='red')

stop()

plot(fit$beta[,1])
plot(fit$beta[,2])
plot(fit$sigma)

plot((1:99)/100, ybar+colMeans(fit$postpred), type='l')

library(BayesTree)

fit.old = bart(x, y, x.test=(1:99)/100, nskip=1000)

plot(density((fit.old$sigma)))
lines(density((fit$sigma)), col='red')

plot((1:99)/100, fit.old$yhat.test.mean, type='l')
lines((1:99)/100, apply(fit.old$yhat.test, 2, quantile, 0.025), lty=2)
lines((1:99)/100, apply(fit.old$yhat.test, 2, quantile, 0.975), lty=2)

lines((1:99)/100, colMeans(fit$postpred), col='red')
lines((1:99)/100, apply(fit$postpred, 2, quantile, 0.025), lty=2, col='red')
lines((1:99)/100, apply(fit$postpred, 2, quantile, 0.975), lty=2, col='red')
