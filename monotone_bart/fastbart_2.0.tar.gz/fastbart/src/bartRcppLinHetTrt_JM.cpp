// This is a working linear (h=1) version of the code
// with half cauchy hyperpriors on var(b(x)) scaled by sigma^2_z
// Lines are kinda dumb so fuck em

// #include <Rcpp.h>
// 
// #include <iostream>
// #include <fstream>
// #include <vector>
// #include <ctime>
// 
// #include "rng.h"
// #include "tree.h"
// #include "info.h"
// #include "funs.h"
// #include "bd.h"
// 
// 
// 
// using namespace Rcpp;
// 
// // [[Rcpp::export]]
// List bartRcppLinHetTrt(NumericVector y_, //outcome
//               NumericVector z_, // treatment
//               NumericVector x_, // covariates
//               NumericVector xhet_, // covariates
//               List xinfo_list,
//               List xhetinfo_list,
//               int burn, int nd, 
//               int m_mu, int m_B, int m_g,
//               double lambda_mu, double nu_mu, double kfac_mu,
//               double lambda_B, double nu_B, double kfac_B,
//               double lambda_g, double nu_g, double kfac_g,
//               CharacterVector treef_mu_name_,
//               CharacterVector treef_B_name_,
//               CharacterVector treef_g_name_,
//               bool save_trees = false,
//               bool RJ= false, bool b_hyperprior = true)
// {
//   
//   double bscale = 1.0;
//   if(b_hyperprior) {
//     Rcout << "Using prior on the variance of b" << endl;
//   }
//   
//   /*
//   std::string treef_name = as<std::string>(treef_name_); 
//   std::ofstream treef(treef_name.c_str());
// 
//   //begin hetero
//   treef_name = as<std::string>(treef_prec_name_); 
//   std::ofstream treefprec(treef_name.c_str());  
//   //end hetero
//   */
//   
//   std::string treef_mu_name = as<std::string>(treef_mu_name_); 
//   std::ofstream treef_mu(treef_mu_name.c_str());
//   
//   std::string treef_B_name = as<std::string>(treef_B_name_); 
//   std::ofstream treef_B(treef_B_name.c_str());
//   
//   std::string treef_g_name = as<std::string>(treef_g_name_); 
//   std::ofstream treef_g(treef_g_name.c_str());
//   
//   
//   RNGScope scope;  
//   RNG gen; //this one random number generator is used in all draws
// 
//   //double lambda = 1.0; //this one really needs to be set
//   //double nu = 3.0;
//   //double kfac=2.0; //original is 2.0
//   
//   Rcout << "\n*****Into bart main\n";
//   
//   /*****************************************************************************
//   / Read, format y
//   *****************************************************************************/
//   std::vector<double> y; //storage for y
//   double miny = INFINITY, maxy = -INFINITY;
//   sinfo allys;       //sufficient stats for all of y, use to initialize the bart trees.
//   
//   for(NumericVector::iterator it=y_.begin(); it!=y_.end(); ++it) {
//     y.push_back(*it);
//     if(*it<miny) miny=*it;
//     if(*it>maxy) maxy=*it;
//     allys.sy += *it; // sum of y
//     allys.sy2 += (*it)*(*it); // sum of y^2
//   }
//   size_t n = y.size();
//   allys.n = n;
//   
//   double ybar = allys.sy/n; //sample mean
//   double shat = sqrt((allys.sy2-n*ybar*ybar)/(n-1)); //sample standard deviation
//   
//   /*****************************************************************************
//   / Read, format z
//   *****************************************************************************/
//   std::vector<double> z; //storage for z
//   double minz = INFINITY, maxz = -INFINITY;
//   sinfo allzs;       
//   
//   for(NumericVector::iterator it=z_.begin(); it!=z_.end(); ++it) {
//     z.push_back(*it);
//     if(*it<minz) minz=*it;
//     if(*it>maxz) maxz=*it;
//     allzs.sy += *it; 
//     allzs.sy2 += (*it)*(*it);
//   }
//   allzs.n = n;
//   
//   double zbar = allzs.sy/n; //sample mean
//   double shatz = sqrt((allzs.sy2-n*zbar*zbar)/(n-1)); //sample standard deviation
//   
//   /*****************************************************************************
//   / Read, format X
//   *****************************************************************************/
//   //read x   
//   //the n*p numbers for x are stored as the p for first obs, then p for second, and so on.
//   std::vector<double> x;
//   for(NumericVector::iterator it=x_.begin(); it!= x_.end(); ++it) {
//     x.push_back(*it);
//   }
//   size_t p = x.size()/n;
//   
//   Rcout <<"\nburn,nd,number of trees: " << burn << ", " << nd << ", " << endl;
//   //Rcout <<"\nlambda,nu,kfac: " << lambda << ", " << nu << ", " << kfac << endl;
//   
//   //x cutpoints
//   xinfo xi;
//   
//   xi.resize(p);
//   for(int i=0; i<p; ++i) {
//     NumericVector tmp = xinfo_list[i];
//     std::vector<double> tmp2;
//     for(size_t j=0; j<tmp.size(); ++j) {
//       tmp2.push_back(tmp[j]);
//     }
//     xi[i] = tmp2;
//   }
//   
//   //read xhet
//   std::vector<double> xhet;
//   for(NumericVector::iterator it=xhet_.begin(); it!= xhet_.end(); ++it) {
//     xhet.push_back(*it);
//   }
//   size_t phet = xhet.size()/n;
//   
//   //Rcout <<"\nlambda,nu,kfac: " << lambda << ", " << nu << ", " << kfac << endl;
//   
//   //x cutpoints
//   xinfo xheti;
//   
//   xheti.resize(phet);
//   for(int i=0; i<phet; ++i) {
//     NumericVector tmp = xhetinfo_list[i];
//     std::vector<double> tmp2;
//     for(size_t j=0; j<tmp.size(); ++j) {
//       tmp2.push_back(tmp[j]);
//     }
//     xheti[i] = tmp2;
//   }
//   
//   
//   //prxi(xi);
//   
//   
//   //size_t nc=100; //100 equally spaced cutpoints from min to max.
//   //makexinfo(p,n,&x[0],xi,nc);
//   
//   /*****************************************************************************
//   /* Setup for MCMC
//   *****************************************************************************/
//   //--------------------------------------------------
//   //trees
//   std::vector<tree> t_mu(m_mu);
//   for(size_t i=0;i<m_mu;i++) t_mu[i].setm(ybar/m_mu); //if you sum the fit over the trees you get the fit.
//   
//   std::vector<tree> t_B(m_B);
//   for(size_t i=0;i<m_B;i++) t_B[i].setm(0); //if you sum the fit over the trees you get the fit.
//   
//   std::vector<tree> t_g(m_g);
//   for(size_t i=0;i<m_g;i++) t_g[i].setm(zbar/m_g); //if you sum the fit over the trees you get the fit.
//   
//   
//   
//   //--------------------------------------------------
//   //prior and mcmc
//   pinfo pi_mu;
//   pi_mu.pbd = 1; //prob of birth/death move
//   pi_mu.pb = .5; //prob of birth given  birth/death
//   
//   pi_mu.alpha = .95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
//   pi_mu.beta = 2.0; //2 for bart means it is harder to build big trees.
//   pi_mu.tau = (maxy-miny)/(2*kfac_mu*sqrt((double)m_mu)); //sigma_mu
//   pi_mu.sigma = shat;
//   
//   pinfo pi_B;
//   pi_B.pbd = 1; //prob of birth/death move
//   pi_B.pb = .5; //prob of birth given  birth/death
//   
//   pi_B.alpha = .95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
//   pi_B.beta = 2.0; //2 for bart means it is harder to build big trees.
//   double b_tau = 1.0/(2*kfac_B*sqrt((double)m_B));
//   pi_B.tau = b_tau; //sigma_mu, will be scaled by sigma_z (pi_g.sigma)
//   pi_B.sigma = 1.0; //shouldn't ever get used.
//   
//   pinfo pi_g;
//   pi_g.pbd = 1; //prob of birth/death move
//   pi_g.pb = .5; //prob of birth given  birth/death
//   
//   pi_g.alpha = .95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
//   pi_g.beta = 2.0; //2 for bart means it is harder to build big trees.
//   pi_g.tau = (maxz-minz)/(2*kfac_g*sqrt((double)m_g)); //sigma_mu
//   pi_g.sigma = shatz;
//   
//   pi_B.tau = b_tau*pi_g.sigma;
//   
//   
//   
//   
// //   
// //   Rcout << "\nalpha, beta: " << pi.alpha << ", " << pi.beta << endl;
// //   Rcout << "sigma, tau: " << pi.sigma << ", " << pi.tau << endl;
// //   
// 
//   //--------------------------------------------------
//   //dinfo
//   double* allfit_mu = new double[n]; //sum of fit of all trees
//   for(size_t i=0;i<n;i++) allfit_mu[i] = ybar;
//   double* r_mu = new double[n]; //y-(allfit_mu-ftemp) = y-allfit_mu+ftemp
//   double* ftemp_mu = new double[n]; //fit of current tree
//   dinfo di_mu;
//   di_mu.n=n; di_mu.p=p; di_mu.x = &x[0]; 
//   di_mu.y=r_mu; //the y for each draw will be the residual 
//   
//   double* allfit_B = new double[n]; //sum of fit of all trees
//   for(size_t i=0;i<n;i++) allfit_B[i] = 0;
//   double* r_B = new double[n]; //y-(allfit_B-ftemp) = y-allfit_B+ftemp
//   double* ftemp_B = new double[n]; //fit of current tree
//   dinfo di_B;
//   di_B.n=n; di_B.p=phet; di_B.x = &xhet[0]; 
//   di_B.y=r_B; //the y for each draw will be the residual 
//   
//   double* allfit_g = new double[n]; //sum of fit of all trees
//   for(size_t i=0;i<n;i++) allfit_g[i] = zbar;
//   double* r_g = new double[n]; //y-(allfit_g-ftemp) = y-allfit_g+ftemp
//   double* ftemp_g = new double[n]; //fit of current tree
//   dinfo di_g;
//   di_g.n=n; di_g.p=p; di_g.x = &x[0]; 
//   di_g.y=r_g; //the y for each draw will be the residual 
//   
//   double* precs = new double[n]; // temp storage for conditional ''precisions''
//   
//   
//   double rss_z, rss_y, restemp_z, restemp_y;
//   
//   NumericVector ssigma_z(nd);
//   NumericVector ssigma_y(nd);
//   NumericMatrix sfit_mu(nd,n);
//   NumericMatrix sfit_B(nd,n);
//   NumericMatrix sfit_g(nd,n);
//   //NumericMatrix spred2(nd,dip.n);
//   
//   int thin = 1;
//   //save stuff to tree file
//   treef_mu << xi << endl; //cutpoints
//   treef_mu << m_mu << endl;  //number of trees
//   treef_mu << p << endl;  //dimension of x's
// 	treef_mu << (int)(nd/thin) << endl;
// 	
// 	treef_B << xheti << endl; //cutpoints
// 	treef_B << m_B << endl;  //number of trees
// 	treef_B << p << endl;  //dimension of x's
// 	treef_B << (int)(nd/thin) << endl;
// 	
// 	treef_g << xi << endl; //cutpoints
// 	treef_g << m_g << endl;  //number of trees
// 	treef_g << p << endl;  //dimension of x's
// 	treef_g << (int)(nd/thin) << endl;
//   
//   /*****************************************************************************
//   /* MCMC
//   *****************************************************************************/
//   Rcout << "\nMCMC:\n";
//   time_t tp;
//   int time1 = time(&tp);
//   
//   std::vector<double> response_trans(n); //Transformed ``response'' variable
//   
//   for(size_t i=0;i<(nd+burn);i++) {
//     if(i%50==0) Rcpp::Rcout << "i: " << i << " sigma_y: "<< pi_mu.sigma << " sigma_z: "<< pi_g.sigma << endl;
//     
//     //Sample mu
//     for(size_t k=0; k<n; ++k) {
//       response_trans[k] = y[k] - bscale*allfit_B[k]*(z[k] - allfit_g[k]);
//     }
//     
//     for(size_t j=0;j<m_mu;j++) {
//        fit(t_mu[j],xi,di_mu,ftemp_mu);
//        for(size_t k=0;k<n;k++) {
//           if(ftemp_mu[k] != ftemp_mu[k]) {
//             Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
//             Rcout << t_mu[j] << endl;
//             stop("nan in ftemp");
//            }
//           allfit_mu[k] = allfit_mu[k] - ftemp_mu[k];
//           r_mu[k] = response_trans[k] - allfit_mu[k];
//        }
// 
//        // bd(t_mu[j],xi,di_mu,pi_mu,gen); 
//        
//        if(gen.uniform()>pi_mu.pbd) {
//          tree::tree_p tnew;
//          tnew=new tree(t_mu[j]); //copy of current to make life easier upon rejection
//          rotp(tnew,t_mu[j],xi,di_mu,pi_mu,gen);
//          delete tnew;
//        } else {
//          bd(t_mu[j],xi,di_mu,pi_mu,gen); 
//        }
//        
//        drmu(t_mu[j],xi,di_mu,pi_mu,gen);
//        fit(t_mu[j],xi,di_mu,ftemp_mu);
//        for(size_t k=0;k<n;k++) allfit_mu[k] += ftemp_mu[k];
//     }
//     
//     // Sample B
//     
//     if (i>=0.0*burn) {
//       for(size_t k=0; k<n; ++k) {
//         double eps_z = bscale*(z[k] - allfit_g[k]);
//         response_trans[k] = (y[k] - allfit_mu[k])/eps_z;
//         precs[k] = eps_z*eps_z/(pi_mu.sigma*pi_mu.sigma);
//       }
//       
//       for(size_t j=0;j<m_B;j++) {
//         fit(t_B[j],xheti,di_B,ftemp_B);
//         for(size_t k=0;k<n;k++) {
//           if(ftemp_B[k] != ftemp_B[k]) {
//             Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
//             Rcout << t_B[j] << endl;
//             stop("nan in ftemp");
//           }
//           allfit_B[k] = allfit_B[k] - ftemp_B[k];
//           r_B[k] = response_trans[k] - allfit_B[k];
//         }
//         //bdhet(t_B[j],xi,di_B,precs,pi_B,gen); 
//         
//         if(gen.uniform()>pi_B.pbd) {
//           tree::tree_p tnew;
//           tnew=new tree(t_B[j]); //copy of current to make life easier upon rejection
//           rotphet(tnew,t_B[j],xheti,di_B,precs,pi_B,gen);
//           delete tnew;
//         } else {
//           bdhet(t_B[j],xheti,di_B,precs,pi_B,gen);
//         }
//         
//         drmuhet(t_B[j],xheti,di_B,precs,pi_B,gen);
//         fit(t_B[j],xheti,di_B,ftemp_B);
//         for(size_t k=0;k<n;k++) allfit_B[k] += ftemp_B[k];
//       }
//     }
//     // Sample g
//     
//     double s2z = pi_g.sigma*pi_g.sigma;
//     double s2y = pi_mu.sigma*pi_mu.sigma;
//     for(size_t k=0; k<n; ++k) {
//       double cov_z_y = s2z*bscale*allfit_B[k];
//       double mar_var_y = s2y + cov_z_y*bscale*allfit_B[k];
//       double coef = cov_z_y/mar_var_y;
//       
//       response_trans[k] = (z[k] - coef*(y[k] - allfit_mu[k]));
//       
//       precs[k] = 1.0/(s2z*(1-bscale*allfit_B[k]*coef));
//     }
//     
//     for(size_t j=0;j<m_g;j++) {
//       fit(t_g[j],xi,di_g,ftemp_g);
//       for(size_t k=0;k<n;k++) {
//         if(ftemp_g[k] != ftemp_g[k]) {
//           Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
//           Rcout << t_g[j] << endl;
//           stop("nan in ftemp");
//         }
//         allfit_g[k] = allfit_g[k] - ftemp_g[k];
//         r_g[k] = response_trans[k] - allfit_g[k];
//       }
//       //bdhet(t_g[j],xi,di_g,precs,pi_g,gen); 
//       if(gen.uniform()>pi_g.pbd) {
//         tree::tree_p tnew;
//         tnew=new tree(t_g[j]); //copy of current to make life easier upon rejection
//         rotphet(tnew,t_g[j],xi,di_g,precs,pi_g,gen);
//         delete tnew;
//       } else {
//         bdhet(t_g[j],xi,di_g,precs,pi_g,gen);
//       }
//       
//       drmuhet(t_g[j],xi,di_g,precs,pi_g,gen);
//       fit(t_g[j],xi,di_g,ftemp_g);
//       for(size_t k=0;k<n;k++) allfit_g[k] += ftemp_g[k];
//     }
//     
//     //draw sigmas
//     rss_y = 0.0;
//     rss_z = 0.0;
//     for(size_t k=0;k<n;k++) {
//       restemp_z = z[k]-allfit_g[k]; 
//       rss_z += restemp_z*restemp_z;
//       restemp_y = y[k] - allfit_mu[k] - bscale*allfit_B[k]*restemp_z;
//       rss_y += restemp_y*restemp_y;
//     }
//     
//     // get all the b parameters for the sigma_z update
//     // 
//     // void drmu(tree& t, xinfo& xi, dinfo& di, pinfo& pi, RNG& gen)
//     // {
//     //   tree::npv bnv;
//     //   std::vector<sinfo> sv;
//     //   allsuff(t,xi,di,bnv,sv);
//     //   
//     //   double a = 1.0/(pi.tau * pi.tau);
//     //   double sig2 = pi.sigma * pi.sigma;
//     //   double b,ybar;
//     //   
//     //   for(tree::npv::size_type i=0;i!=bnv.size();i++) {
//     //     b = sv[i].n/sig2;
//     //     ybar = sv[i].sy/sv[i].n;
//     //     bnv[i]->setm(b*ybar/(a+b) + gen.normal()/sqrt(a+b));
//     //     if(bnv[i]->getm() != bnv[i]->getm()) {
//     //       for(int i=0; i<di.n; ++i) Rcout << *(di.x + i*di.p) <<" "; //*(x + p*i+j)
//     //       Rcout << endl<<" a "<< a<<" b "<<b<<" svi[n] "<<sv[i].n<<" i "<<i;
//     //       Rcout << endl << t;
//     //       Rcpp::stop("drmu failed");
//     //     }
//     //   }
//     // }
//     
//     
//     double ssq_b = 0.0;
//     tree::npv bnv;
//     typedef tree::npv::size_type bvsz;
//     double endnode_count = 0.0;
//     
//     for(size_t j=0;j<m_B;j++) {
//       bnv.clear();
//       t_B[j].getbots(bnv);
//       bvsz nb = bnv.size();
//       for(bvsz ii = 0; ii<nb; ++ii) {
//         double mm = bnv[ii]->getm(); //node parameter
//         ssq_b += mm*mm/(b_tau*b_tau);
//         endnode_count += 1.0;
//       }
//     }
//     
//     
//     // 
//     //update sigma_z
//     pi_g.sigma = sqrt((nu_g*lambda_g + rss_z + ssq_b)/gen.chi_square(nu_g+n+endnode_count));
//     pi_B.tau = b_tau*pi_g.sigma;
//     
//     //update sigma_y
//     pi_mu.sigma = sqrt((nu_mu*lambda_mu + rss_y)/gen.chi_square(nu_mu+n));
//     
//     //update bscale
//     // define q_i = (y_i - m(x_i))/(b(x)*(z-g(x))) ~ N(bscale, sigma^2_z/phi_i)
//     // with 1/phi_i = 1/(b^2(x)*(z-g(x))^2)
//     // this is lazy but notationally convenient
//     if(b_hyperprior) {
//       double qbar = 0.0;
//       double sumphi = 0.0;
//       for(size_t k=0;k<n;k++) {
//         double bres = allfit_B[k]*(z[k] - allfit_g[k]);
//         double q = (y[k] - allfit_mu[k])/bres;
//         double phi = bres*bres;
//         qbar += phi*q;
//         sumphi += phi;
//       }
//       double s2z = (pi_g.sigma*pi_g.sigma);
//       qbar /= s2z;
//       sumphi /= s2z;
//       
//       // bscale ~ N(0,1) wlog
//       
//       bscale = qbar/(1 + sumphi) + sqrt(1/(1 + sumphi))*gen.normal(0,1);
//     }
//     
//     if(i>=burn) {
//       for(size_t j=0;j<m_mu;j++) treef_mu << t_mu[j] << endl;
//       for(size_t j=0;j<m_B;j++) treef_B << t_B[j] << endl;
//       for(size_t j=0;j<m_g;j++) treef_g << t_g[j] << endl;
//       
//       ssigma_y(i-burn) = pi_mu.sigma;
//       ssigma_z(i-burn) = pi_g.sigma;
//       for(size_t k=0;k<n;k++) {
//         //pmean[k] += allfit[k];
//         sfit_mu(i-burn, k) = allfit_mu[k];
//         sfit_B(i-burn, k) = bscale*allfit_B[k];
//         sfit_g(i-burn, k) = allfit_g[k];
//       }
// //       if(dip.n) {
// //         for(size_t k=0;k<dip.n;k++) {
// //           spred2(i-burn, k) = fit_i(k, t, xi, dip); //tested good
// //           //spred2prec(i-burn, k) = fit_i(k, tprec, xiprec,/ dipprec);
// //         }
// //       }
//     }
//   }
//   int time2 = time(&tp);
//   Rcout << "time for loop: " << time2 - time1 << endl;
// 
//   //NumericVector bfit(n);
//   //for(size_t i=0;i<n;i++) bfit[i] = pmean[i]/ (double)nd;
//   
//   //NumericVector bpred(dip.n);
//   //for(size_t i=0;i<dip.n;i++) bpred[i] = ppredmean[i]/ (double)nd;
// 
//   t_mu.clear();
//   delete[] allfit_mu;
//   delete[] r_mu;
//   delete[] ftemp_mu;
//   t_B.clear();
//   delete[] allfit_B;
//   delete[] r_B;
//   delete[] ftemp_B;
//   t_g.clear();
//   delete[] allfit_g;
//   delete[] r_g;
//   delete[] ftemp_g;
//   //delete[] pmean;
//   //delete[] ppredmean;
//   //delete[] fpredtemp;
//   
//   treef_mu.close();
//   treef_g.close();
//   treef_B.close();
// 
//   return(List::create(_["sigma_y"] = ssigma_y,
//                       _["sigma_z"] = ssigma_z,
//                       _["post_mu"] = sfit_mu, 
//                       _["post_g"] = sfit_g, 
//                       _["post_B"] = sfit_B
//                       //_["postpred"] = spred, 
// //                      _["postprecfit"] = sfitprec
//                       ));
// }
