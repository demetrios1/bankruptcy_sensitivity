#include <Rcpp.h>

#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>

#include "rng.h"
#include "tree.h"
#include "info.h"
#include "funs.h"
#include "bd.h"

using std::cout;
using std::endl;
using namespace Rcpp;

// [[Rcpp::export]]
List bartRcpp(NumericVector y_, IntegerVector ymask_, NumericVector x_, NumericVector xpred_, 
              IntegerVector cx_, IntegerVector x_type_, IntegerVector offsets_,
              IntegerMatrix xmask_, IntegerMatrix x_cat_,
              int burn, int nd, int m, size_t num_u)
{
  RNGScope scope;  
  RNG gen; //this one random number generator is used in all draws
  //--------------------------------------------------
  //optionally read in additional arguments
  //size_t burn = 1000; //number of mcmc iterations called burn-in
  //size_t nd = 1000; //number of mcmc iterations
  //size_t m = 200; //number of trees in BART sum
  double lambda = 1.0; //this one really needs to be set
  double nu = 3.0;
  double kfac=2.0; //original is 2.0
  
  //lookup_t ta = make_lookup(lookup_table, cx);
  //for(int v=0; v<11; ++v) Rcout << ta[v][0]<<" "<<endl;
  
  Rcout << "\n*****Into bart main\n";
  
  /*****************************************************************************
  /* Read data format parameters
  *****************************************************************************/
  typedef IntegerVector::iterator rcppint_it;
  std::vector<int> cx, x_type, offsets;
  for(rcppint_it it=cx_.begin(); it !=cx_.end(); ++it) {
    cx.push_back(*it);
  }
  for(rcppint_it it=x_type_.begin(); it !=x_type_.end(); ++it) {
    x_type.push_back(*it);
  }
  for(rcppint_it it=offsets_.begin(); it !=offsets_.end(); ++it) {
    offsets.push_back(*it);
  }
  
  /*****************************************************************************
  /* Read, format y
  *****************************************************************************/
  std::vector<double> y; //storage for y
  double miny = INFINITY, maxy = -INFINITY;
  sinfo allys;       //sufficient stats for all of y, use to initialize the bart trees.
  
  for(NumericVector::iterator it=y_.begin(); it!=y_.end(); ++it) {
    y.push_back(*it);
    if(*it<miny) miny=*it;
    if(*it>maxy) maxy=*it;
    allys.sy += *it; // sum of y
    allys.sy2 += (*it)*(*it); // sum of y^2
  }
  size_t n = y.size();
  allys.n = n;
  
  double ybar = allys.sy/n; //sample mean
  double shat = sqrt((allys.sy2-n*ybar*ybar)/(n-1)); //sample standard deviation
  
  vector<int> ymask;
  for(IntegerVector::iterator it=ymask_.begin(); it!=ymask_.end(); ++it) {
    ymask.push_back(*it);
  }
  
  /*****************************************************************************
  /* Read, format X, Xpred
  *****************************************************************************/
  //Keep the original categorical representation of X
  vector<vector<int> > x_cat(n, vector<int>(cx.size()));
  for(int i=0; i<n; ++i) {
   for(int j=0; j<cx.size(); ++j) x_cat[i][j] = x_cat_(i,j);
  }
  
  //read x   
  //the n*p numbers for x are stored as the p for first obs, then p for second, and so on.
  std::vector<double> x;
  for(NumericVector::iterator it=x_.begin(); it!= x_.end(); ++it) {
    x.push_back(*it);
  }
  size_t p = x.size()/n;
  
  //for(int s = 65868; s<(65868+44); s++) Rcout << x[s] << " " << endl;
  
  //x for predictions
  dinfo dip; //data information for prediction
  dip.n=0;
  std::vector<double> xp;     //prediction observations, stored like x
  if(xpred_.size()) {
    for(NumericVector::iterator it=xpred_.begin(); it!=xpred_.end(); ++it) {
       xp.push_back(*it);
    }
    size_t np = xp.size()/p;
    if(xp.size() != np*p) Rcout << "error, wrong number of elements in prediction data set\n";
    if(np) dip.n=np; dip.p=p; dip.x = &xp[0]; dip.y=0; //there are no y's!
  }
  
  Rcout <<"\nburn,nd,number of trees: " << burn << ", " << nd << ", " << m << endl;
  Rcout <<"\nlambda,nu,kfac: " << lambda << ", " << nu << ", " << kfac << endl;
  
  //--------------------------------------------------
  //x cutpoints
  xinfo xi;
  size_t nc=100; //100 equally spaced cutpoints from min to max.
  makexinfo(p,n,&x[0],xi,nc);
  
  /*****************************************************************************
  /* Setup for MCMC
  *****************************************************************************/
  //--------------------------------------------------
  //trees
  std::vector<tree> t(m);
  for(size_t i=0;i<m;i++) t[i].setm(ybar/m); //if you sum the fit over the trees you get the fit.
  
  //--------------------------------------------------
  //prior and mcmc
  pinfo pi;
  pi.pbd=1.0; //prob of birth/death move
  pi.pb=.5; //prob of birth given  birth/death
  
  pi.alpha=.95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
  pi.beta=2.0; //2 for bart means it is harder to build big trees.
  pi.tau=(maxy-miny)/(2*kfac*sqrt((double)m));
  pi.sigma=shat;
  
  Rcout << "\nalpha, beta: " << pi.alpha << ", " << pi.beta << endl;
  Rcout << "sigma, tau: " << pi.sigma << ", " << pi.tau << endl;
  
  //--------------------------------------------------
  //dinfo
  double* allfit = new double[n]; //sum of fit of all trees
  for(size_t i=0;i<n;i++) allfit[i]=ybar;
  double* r = new double[n]; //y-(allfit-ftemp) = y-allfit+ftemp
  double* ftemp = new double[n]; //fit of current tree
  dinfo di;
  di.n=n; di.p=p; di.x = &x[0]; di.y=r; //the y for each draw will be the residual 
  
  //--------------------------------------------------
  //storage for ouput
  //in sample fit
  double* pmean = new double[n]; //posterior mean of in-sample fit, sum draws,then divide
  for(size_t i=0;i<n;i++) pmean[i]=0.0;
  
  //out of sample fit
  double* ppredmean=0; //posterior mean for prediction
  double* fpredtemp=0; //temporary fit vector to compute prediction
  if(dip.n) {
    ppredmean = new double[dip.n];
    fpredtemp = new double[dip.n];
    for(size_t i=0;i<dip.n;i++) ppredmean[i]=0.0;
  }
  //for sigma draw
  double rss, restemp;
  
  NumericVector ssigma(nd);
  NumericMatrix sfit(nd,n);
  NumericMatrix spred(nd,dip.n);
  NumericMatrix spred2(nd,dip.n);
  
  /*****************************************************************************
  /* MCMC
  *****************************************************************************/
  Rcout << "\nMCMC:\n";
  time_t tp;
  int time1 = time(&tp);
  
  for(size_t i=0;i<(nd+burn);i++) {
    /*
    Rcout << "current X" << endl <<endl;
    for(int ii=0; ii<n; ++ii) {
      for(int c=0; c<44; ++c) {
        Rcout << x[ii*p+c]<< " ";
      }
      Rcout << endl;
    }
    */
    
    
    if(i%50==0) cout << "i: " << i << " sigma: "<< pi.sigma << endl;
    //draw trees
    for(size_t j=0;j<m;j++) {
       fit(t[j],xi,di,ftemp);
       for(size_t k=0;k<n;k++) {
          if(ftemp[k] != ftemp[k]) {
            Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
            int pp=0;
            /*
            for(int c=0; c<cx.size(); ++c) {
              Rcout << endl << "var "<<c << endl;
              if(x_type[c]<3) {
                Rcout << x[k+pp] << endl;
                ++pp;
              } else {
                for(int s=0; s<cx[c]; ++s) {
                  Rcout << x[k+pp] << endl;
                  ++pp;
                }
              }
            }
            */
            Rcout << t[j] << endl;
            stop("nan in ftemp");
           }
          allfit[k] = allfit[k]-ftemp[k];
          r[k] = y[k]-allfit[k];
       }
       bd(t[j],xi,di,pi,gen);
       drmu(t[j],xi,di,pi,gen);
       fit(t[j],xi,di,ftemp);
       for(size_t k=0;k<n;k++) allfit[k] += ftemp[k];
    }
    //do imputation for y
    /*
    for(int ii=0; ii<n; ++ii) {
      if(ymask[ii]) y[ii] = R::rnorm(allfit[ii], pi.sigma);
    }
    */
    //Rcout << endl;
    //draw sigma
    rss=0.0;
    for(size_t k=0;k<n;k++) {restemp=y[k]-allfit[k]; rss += restemp*restemp;}
    //Rcout << rss << endl;
    pi.sigma = sqrt((nu*lambda + rss)/gen.chi_square(nu+n));
    
    /*
    for(size_t j=0;j<m;j++) {
       fit(t[j],xi,di,ftemp);
       for(size_t k=0;k<n;k++) allfit[k] += ftemp[k];
    }
    */
    
    //bsdf << pi.sigma << endl;
    if(i>=burn) {
      ssigma(i-burn) = pi.sigma;
       for(size_t k=0;k<n;k++) {
         pmean[k] += allfit[k];
         sfit(i-burn, k) = allfit[k];
       }
       if(dip.n) {
         for(size_t k=0;k<dip.n;k++) {
           spred2(i-burn, k) = fit_i(k, t, xi, dip); //tested good
         }
       }
    }
  }
  int time2 = time(&tp);
  Rcout << "time for loop: " << time2-time1 << endl;
  
  for(size_t k=0;k<n;k++) pmean[k] /= (double)nd;

  NumericVector bfit(n);
  for(size_t i=0;i<n;i++) bfit[i] = pmean[i];
  
  NumericVector bpred(dip.n);
  for(size_t i=0;i<dip.n;i++) bpred[i] = ppredmean[i]/= (double)nd;

  t.clear();
  delete[] allfit;
  delete[] r;
  delete[] ftemp;
  delete[] pmean;
  delete[] ppredmean;
  delete[] fpredtemp;

  return(List::create(_["insample"] = bfit, _["pred"] = bpred, _["sigma"] = ssigma,
                      _["postfit"] = sfit, _["postpred"] = spred, _["postpred_test"] = spred2));
}
