#include <Rcpp.h>

#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>

#include "rng.h"
#include "tree.h"
#include "info.h"
#include "funs.h"
#include "bd.h"



using namespace Rcpp;

// [[Rcpp::export]]
List bartRcppClean(NumericVector y_, NumericVector x_, NumericVector xpred_,
              List xinfo_list,
              int burn, int nd, int m,
              double lambda, double nu, double kfac,
              CharacterVector treef_name_,
              bool RJ= false)
{

  std::string treef_name = as<std::string>(treef_name_);
  std::ofstream treef(treef_name.c_str());

  RNGScope scope;
  RNG gen; //this one random number generator is used in all draws

  Rcout << "\n*****Into bart main\n";

  /*****************************************************************************
  /* Read, format y
  *****************************************************************************/
  std::vector<double> y; //storage for y
  double miny = INFINITY, maxy = -INFINITY;
  sinfo allys;       //sufficient stats for all of y, use to initialize the bart trees.

  for(NumericVector::iterator it=y_.begin(); it!=y_.end(); ++it) {
    y.push_back(*it);
    if(*it<miny) miny=*it;
    if(*it>maxy) maxy=*it;
    allys.sy += *it; // sum of y
    allys.sy2 += (*it)*(*it); // sum of y^2
  }
  size_t n = y.size();
  allys.n = n;

  double ybar = allys.sy/n; //sample mean
  double shat = sqrt((allys.sy2-n*ybar*ybar)/(n-1)); //sample standard deviation

  /*****************************************************************************
  /* Read, format X, Xpred
  *****************************************************************************/
  //read x
  //the n*p numbers for x are stored as the p for first obs, then p for second, and so on.
  std::vector<double> x;
  for(NumericVector::iterator it=x_.begin(); it!= x_.end(); ++it) {
    x.push_back(*it);
  }
  size_t p = x.size()/n;

  //x for predictions
  dinfo dip; //data information for prediction
  dip.n = 0;
  std::vector<double> xp;     //stored like x
  if(xpred_.size()) {
    for(NumericVector::iterator it=xpred_.begin(); it!=xpred_.end(); ++it) {
       xp.push_back(*it);
    }
    size_t np = xp.size()/p;
    if(xp.size() != np*p) Rcout << "error, wrong number of elements in prediction data set\n";
    if(np) dip.n=np; dip.p=p; dip.x = &xp[0]; dip.y=0; //there are no y's!
  }

  Rcout <<"\nburn,nd,number of trees: " << burn << ", " << nd << ", " << m << endl;
  Rcout <<"\nlambda,nu,kfac: " << lambda << ", " << nu << ", " << kfac << endl;

  //x cutpoints
  xinfo xi;

  xi.resize(p);
  for(int i=0; i<p; ++i) {
    NumericVector tmp = xinfo_list[i];
    std::vector<double> tmp2;
    for(size_t j=0; j<tmp.size(); ++j) {
      tmp2.push_back(tmp[j]);
    }
    xi[i] = tmp2;
  }

  //prxi(xi);


  //size_t nc=100; //100 equally spaced cutpoints from min to max.
  //makexinfo(p,n,&x[0],xi,nc);

  /*****************************************************************************
  /* Setup for MCMC
  *****************************************************************************/
  //--------------------------------------------------
  //trees
  std::vector<tree> t(m);
  for(size_t i=0;i<m;i++) t[i].setm(ybar/m); //if you sum the fit over the trees you get the fit.

  //--------------------------------------------------
  //prior and mcmc
  pinfo pi;
  pi.pbd = 1.0; //prob of birth/death move
  pi.pb = .5; //prob of birth given  birth/death

  pi.alpha = .95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
  pi.beta = 2.0; //2 for bart means it is harder to build big trees.
  pi.tau = (maxy-miny)/(2*kfac*sqrt((double)m)); //sigma_mu
  pi.sigma = shat;

  Rcout << "\nalpha, beta: " << pi.alpha << ", " << pi.beta << endl;
  Rcout << "sigma, tau: " << pi.sigma << ", " << pi.tau << endl;

  //--------------------------------------------------
  //dinfo
  double* allfit = new double[n]; //sum of fit of all trees
  for(size_t i=0;i<n;i++) allfit[i] = ybar;
  double* r = new double[n]; //y-(allfit-ftemp) = y-allfit+ftemp
  double* ftemp = new double[n]; //fit of current tree
  dinfo di;
  di.n=n; di.p=p; di.x = &x[0]; di.y=r; //the y for each draw will be the residual

  //--------------------------------------------------
  //storage for ouput
  //in sample fit
  double* pmean = new double[n]; //posterior mean of in-sample fit, sum draws,then divide
  for(size_t i=0;i<n;i++) pmean[i]=0.0;

  //out of sample fit
  double* ppredmean=0; //posterior mean for prediction
  double* fpredtemp=0; //temporary fit vector to compute prediction
  if(dip.n) {
    ppredmean = new double[dip.n];
    fpredtemp = new double[dip.n];
    for(size_t i=0;i<dip.n;i++) ppredmean[i]=0.0;
  }
  //for sigma draw
  double rss, restemp;

  NumericVector ssigma(nd);
  NumericMatrix sfit(nd,n);
  NumericMatrix spred2(nd,dip.n);

  int thin = 1;
  //save stuff to tree file
  treef << xi << endl; //cutpoints
	treef << m << endl;  //number of trees
	treef << p << endl;  //dimension of x's
	treef << (int)(nd/thin) << endl;

  /*****************************************************************************
  /* MCMC
  *****************************************************************************/
  Rcout << "\nMCMC:\n";
  time_t tp;
  int time1 = time(&tp);

  for(size_t i=0;i<(nd+burn);i++) {
    if(i%50==0) cout << "i: " << i << " sigma: "<< pi.sigma << endl;
    //draw trees
    for(size_t j=0;j<m;j++) {
       fit(t[j],xi,di,ftemp);
       for(size_t k=0;k<n;k++) {
          if(ftemp[k] != ftemp[k]) {
            Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
            Rcout << t[j] << endl;
            stop("nan in ftemp");
           }
          allfit[k] = allfit[k]-ftemp[k];
          r[k] = y[k]-allfit[k];
       }
       if(RJ) {
         bd_rj(t[j],xi,di,pi,gen);
       } else {
         bd(t[j],xi,di,pi,gen);
       }
       drmu(t[j],xi,di,pi,gen);
       fit(t[j],xi,di,ftemp);
       for(size_t k=0;k<n;k++) allfit[k] += ftemp[k];
    }

    //draw sigma
    rss = 0.0;
    for(size_t k=0;k<n;k++) {
      restemp = y[k]-allfit[k];
      rss += restemp*restemp;
    }
    pi.sigma = sqrt((nu*lambda + rss)/gen.chi_square(nu+n));

    if(i>=burn) {
      for(size_t j=0;j<m;j++) treef << t[j] << endl;

      ssigma(i-burn) = pi.sigma;
       for(size_t k=0;k<n;k++) {
         pmean[k] += allfit[k];
         sfit(i-burn, k) = allfit[k];
       }
       if(dip.n) {
         for(size_t k=0;k<dip.n;k++) {
           spred2(i-burn, k) = fit_i(k, t, xi, dip); //tested good
         }
       }
    }
  }
  int time2 = time(&tp);
  Rcout << "time for loop: " << time2 - time1 << endl;

  NumericVector bfit(n);
  for(size_t i=0;i<n;i++) bfit[i] = pmean[i]/ (double)nd;

  NumericVector bpred(dip.n);
  for(size_t i=0;i<dip.n;i++) bpred[i] = ppredmean[i]/ (double)nd;

  t.clear();
  delete[] allfit;
  delete[] r;
  delete[] ftemp;
  delete[] pmean;
  delete[] ppredmean;
  delete[] fpredtemp;

  treef.close();

  return(List::create(_["insample"] = bfit, _["pred"] = bpred, _["sigma"] = ssigma,
                      _["postfit"] = sfit, //_["postpred"] = spred,
                      _["postpred"] = spred2));
}
