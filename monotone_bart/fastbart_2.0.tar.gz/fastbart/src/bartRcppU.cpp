//
//#include <Rcpp.h>
//
//#include <iostream>
//#include <fstream>
//#include <vector>
//#include <ctime>
//
//#include "rng.h"
//#include "tree.h"
//#include "info.h"
//#include "funs.h"
//#include "bd.h"
//#include "slice.h"
//
//using std::cout;
//using std::endl;
//using namespace Rcpp;
//
//// [[Rcpp::export]]
//List bartRcppU(NumericVector y_, IntegerVector ymask_, NumericVector x_, NumericVector xpred_, 
//              IntegerVector cx_, IntegerVector x_type_, IntegerVector offsets_,
//              IntegerMatrix xmask_, IntegerMatrix x_cat_, NumericVector ugrid, double fix_sigma,
//              int burn, int nd, int m, size_t num_u, List xinfo_list, int fix_pred_u, int status)
//{
//  bool SLICE = false;
//  RNGScope scope;  
//  RNG gen; //this one random number generator is used in all draws
//  //--------------------------------------------------
//  //optionally read in additional arguments
//  //size_t burn = 1000; //number of mcmc iterations called burn-in
//  //size_t nd = 1000; //number of mcmc iterations
//  //size_t m = 200; //number of trees in BART sum
//  double lambda = 2; //this one really needs to be set - default is 1
//  double nu = 3.0; // default is 3
//  double kfac = 2.0; //original is 2.0
//  
//  //lookup_t ta = make_lookup(lookup_table, cx);
//  //for(int v=0; v<11; ++v) Rcout << ta[v][0]<<" "<<endl;
//  
//  Rcout << "\n*****Into bart main\n";
//  
//  /*****************************************************************************
//  /* Read data format parameters
//  *****************************************************************************/
//  typedef IntegerVector::iterator rcppint_it;
//  std::vector<int> cx, x_type, offsets;
//  for(rcppint_it it=cx_.begin(); it !=cx_.end(); ++it) {
//    cx.push_back(*it);
//  }
//  for(rcppint_it it=x_type_.begin(); it !=x_type_.end(); ++it) {
//    x_type.push_back(*it);
//  }
//  for(rcppint_it it=offsets_.begin(); it !=offsets_.end(); ++it) {
//    offsets.push_back(*it);
//  }
//  
//  /*****************************************************************************
//  /* Read, format y
//  *****************************************************************************/
//  std::vector<double> y; //storage for y
//  double miny = INFINITY, maxy = -INFINITY;
//  sinfo allys;       //sufficient stats for all of y, use to initialize the bart trees.
//  
//  for(NumericVector::iterator it=y_.begin(); it!=y_.end(); ++it) {
//    y.push_back(*it);
//    if(*it<miny) miny=*it;
//    if(*it>maxy) maxy=*it;
//    allys.sy += *it; // sum of y
//    allys.sy2 += (*it)*(*it); // sum of y^2
//  }
//  size_t n = y.size();
//  allys.n = n;
//  
//  double ybar = allys.sy/n; //sample mean
//  double shat = sqrt((allys.sy2-n*ybar*ybar)/(n-1)); //sample standard deviation
//  
//  vector<int> ymask;
//  for(IntegerVector::iterator it=ymask_.begin(); it!=ymask_.end(); ++it) {
//    ymask.push_back(*it);
//  }
//  
//  /*****************************************************************************
//  /* Read, format X, Xpred
//  *****************************************************************************/
//  
//  //read x   
//  //the n*p numbers for x are stored as the p for first obs, then p for second, and so on.
//  std::vector<double> x;
//  for(NumericVector::iterator it=x_.begin(); it!= x_.end(); ++it) {
//    x.push_back(*it);
//  }
//  size_t p = x.size()/n;
//  //size_t first_u = p - num_u;
//  //size_t num_x   = p - first_u;
//  
//  /*
//  for(int j=0; j<num_u; ++j) {
//    for(int k=0; k<n; ++k) {
//      Rcout <<x[j+k*p] << " ";
//    }
//    Rcout << endl << endl;
//  }
//  */
//  
//  //Rcout <<std::endl << first_u << " " << num_x<<endl;
//  
//  //for(int s = 65868; s<(65868+44); s++) Rcout << x[s] << " " << endl;
//  
//  //x for predictions
//  dinfo dip; //data information for prediction
//  dip.n=0;
//  std::vector<double> xp;     //prediction observations, stored like x
//  if(xpred_.size()) {
//    for(NumericVector::iterator it=xpred_.begin(); it!=xpred_.end(); ++it) {
//       xp.push_back(*it);
//    }
//    size_t np = xp.size()/p;
//    if(xp.size() != np*p) Rcout << "error, wrong number of elements in prediction data set\n";
//    if(np) dip.n=np; dip.p=p; dip.x = &xp[0]; dip.y=0; //there are no y's!
//  }
//  
//  Rcout <<"\nburn,nd,number of trees: " << burn << ", " << nd << ", " << m << endl;
//  Rcout <<"\nlambda,nu,kfac: " << lambda << ", " << nu << ", " << kfac << endl;
//  
//  //--------------------------------------------------
//  //x cutpoints
//  xinfo xi;
//  
//  xi.resize(p);
//  for(int i=0; i<p; ++i) {
//    NumericVector tmp = xinfo_list[i];
//    std::vector<double> tmp2;
//    for(size_t j=0; j<tmp.size(); ++j) {
//      tmp2.push_back(tmp[j]);
//    }
//    xi[i] = tmp2;
//  }
//  
//  prxi(xi);
//  
//  //Rcout << xi;
//  /*
//  xi.clear();
//  size_t nc = 100; //100 equally spaced cutpoints from min to max.
//  makexinfo(p,n,&x[0],xi,nc);
//  */
//  /*****************************************************************************
//  /* Setup for MCMC
//  *****************************************************************************/
//  //--------------------------------------------------
//  //trees
//  std::vector<tree> t(m);
//  for(size_t i=0;i<m;i++) t[i].setm(ybar/m); //if you sum the fit over the trees you get the fit.
//  
//  //--------------------------------------------------
//  //prior and mcmc
//  pinfo pi;
//  pi.pbd=1.0; //prob of birth/death move
//  pi.pb=.5; //prob of birth given  birth/death
//  
//  pi.alpha=.95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
//  pi.beta=2.0; //2 for bart means it is harder to build big trees.
//  pi.tau=(maxy-miny)/(2*kfac*sqrt((double)m));
//  pi.sigma=shat;
//  
//  Rcout << "\nalpha, beta: " << pi.alpha << ", " << pi.beta << endl;
//  Rcout << "sigma, tau: " << pi.sigma << ", " << pi.tau << endl;
//  
//  //--------------------------------------------------
//  //dinfo
//  double* allfit = new double[n]; //sum of fit of all trees
//  for(size_t i=0;i<n;i++) allfit[i]=ybar;
//  double* r = new double[n]; //y-(allfit-ftemp) = y-allfit+ftemp
//  double* ftemp = new double[n]; //fit of current tree
//  dinfo di;
//  di.n=n; di.p=p; di.x = &x[0]; di.y=r; //the y for each draw will be the residual 
//  
//  //--------------------------------------------------
//  //storage for ouput
//  //in sample fit
//  double* pmean = new double[n]; //posterior mean of in-sample fit, sum draws,then divide
//  for(size_t i=0;i<n;i++) pmean[i] = 0.0;
//  
//  //out of sample fit
//  double* ppredmean=0; //posterior mean for prediction
//  double* fpredtemp=0; //temporary fit vector to compute prediction
//  if(dip.n) {
//    ppredmean = new double[dip.n];
//    fpredtemp = new double[dip.n];
//    for(size_t i=0;i<dip.n;i++) ppredmean[i] = 0.0;
//  }
//  //for sigma draw
//  double rss, restemp;
//  
//  NumericVector ssigma(nd);
//  NumericMatrix sfit(nd,n);
//  NumericMatrix spred(nd,dip.n);
//  NumericMatrix spred2(nd,dip.n);
//  
//  /*****************************************************************************
//  /* MCMC
//  *****************************************************************************/
//  
//  tree::npv bnv;
//  std::vector<tree::npv> bnvs;
//  std::vector<std::vector<int> > leaf_counts(m);
//  std::vector<double> lik(ugrid.size());
//  std::vector<tree> using_u;
//  
//  ld_bartU slice_density(0.0, 1.0);
//  slice_density.xi = xi;
//  slice_density.di = di;
//  slice_density.i = 0;
//  slice_density.using_u = using_u;
//  
//  Rcout << "\nMCMC:\n";
//  time_t tp;
//  int time1 = time(&tp);
//  
//  for(size_t i=0;i<(nd+burn);i++) {
//    
//    //tree::npv bnv;
//    //std::vector<int> cts;
//    //cts = counts(t[0], xi, di, bnv);
//    //for(size_t ii=0; ii<cts.size(); ++ii) {
//    //  Rcout << cts[ii] << " ";
//    //}
//    //Rcout << endl;
//    
//    R_CheckUserInterrupt();
//    if(i%status==0) {
//      cout << "i: " << i << " sigma: "<< pi.sigma << endl;
//      for(size_t tt=0; tt<t.size(); ++tt) {
//        Rcout << t[tt].nuse(0) << " ";
//      }
//      Rcout << endl;
//    }
//    //draw trees
//    for(size_t j=0;j<m;j++) {
//       fit(t[j],xi,di,ftemp);
//       for(size_t k=0;k<n;k++) {
//          if(ftemp[k] != ftemp[k]) {
//            Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
//            Rcout << t[j] << endl;
//            stop("nan in ftemp");
//           }
//          allfit[k] = allfit[k]-ftemp[k];
//          r[k] = y[k]-allfit[k];
//       }
//       bd(t[j],xi,di,pi,gen);
//       drmu(t[j],xi,di,pi,gen);
//       fit(t[j],xi,di,ftemp);
//       for(size_t k=0;k<n;k++) allfit[k] += ftemp[k];
//    }
//    
//    /*** sample u ***/
//    using_u.clear();
//    leaf_counts.clear();
//    bnvs.clear();
//    vector<std::map<tree::tree_cp,size_t> > bnmaps;
//    std::set<size_t> ucuts; ucuts.insert(0); ucuts.insert(xi[0].size()-1);
//    
//    //get trees splitting on u, the first variable
//    for(int tt=0; tt<m; ++tt) {
//      if(t[tt].nuse(0)) {
//        using_u.push_back(t[tt]);
//      }
//    }
//    
//    //update slice_density object
//    slice_density.sigma = pi.sigma;
//    slice_density.using_u = using_u;
//    
//    //get leaf counts for each tree splitting on u, also get partition of u
//    for(size_t tt=0; tt<using_u.size(); ++tt) {
//      leaf_counts.push_back(counts(using_u[tt], xi, di, bnv)); //clears & populates bnv
//      bnvs.push_back(bnv);
//      using_u[tt].varsplits(ucuts, 0);
//    }
//    
//    std::vector<size_t> ucutsv(ucuts.begin(), ucuts.end());
//    std::vector<double> logpr(ucuts.size()-1);
//    /*
//    Rcout<< endl;
//    for(std::set<size_t>::iterator it=ucuts.begin(); it != ucuts.end(); ++it) {
//      Rcout << *it << " ";
//    }
//    Rcout << endl;
//    */
//    //prebuild ix->bottom node maps for each tree splitting on u, big time saver.
//    typedef tree::npv::size_type bvsz;
//    for(size_t tt=0; tt<using_u.size(); ++tt) {
//      bvsz nb = bnvs[tt].size();
//      std::map<tree::tree_cp,size_t> bnmap;
//	    for(bvsz ii=0;ii!=bnvs[tt].size();ii++) bnmap[bnvs[tt][ii]]=ii; 
//      bnmaps.push_back(bnmap);
//    }
//    /*
//    Rcout << "leaf cts init: ";
//    for(size_t mm=0; mm<using_u.size(); ++mm) {
//      for(size_t tt = 0; tt<leaf_counts[mm].size(); ++tt) {
//        Rcout << leaf_counts[mm][tt] << " ";
//      }
//    }
//    Rcout << endl;
//    */
//    //loop over each observation
//    std::vector<int> tmpcounts;
//    for(size_t k=0;k<n;k++) {
//      bool proceed = true;
//      for(size_t j=0; j<num_u; ++j) { // <-- vestigal from >1 latent variable days, remove?
//        //check that removing u won't result in bottom nodes 
//        //todo: sample u uniformly from current partition? does that help?
//        for(size_t tt=0; tt<using_u.size(); ++tt) {
//          tmpcounts = leaf_counts[tt];
//          update_counts(k, tmpcounts, using_u[tt], xi, di, bnmaps[tt], -1); 
//          if(*std::min_element(tmpcounts.begin(), tmpcounts.end())<5) {
//            proceed = false;
//            //Rcout << "skipping u because proceed is " << proceed << endl;
//            break;
//          }
//        }
//        
//        //resample u
//        if(proceed) {
//          //take out u, decrement counts - should use tmpcounts from above, right?? computing 2x?
//          for(size_t tt=0; tt<using_u.size(); ++tt) {
//            update_counts(k, leaf_counts[tt], using_u[tt], xi, di, bnmaps[tt], -1);
//          }
//          
//          double f = allfit[k] - fit_i(k, using_u, xi, di); //fit from trees that don't use u
//          
//          if(!SLICE) {
//            /*
//            for(size_t uu=0; uu<ugrid.size(); ++uu) {
//              x[j+k*p] = ugrid[uu];
//              double newfit = f + fit_i(k, using_u, xi, di);
//              lik[uu] = -0.5*pow((y[k] - newfit)/pi.sigma, 2);
//            }
//            int uix = rdisc_log(lik);
//            //stop("line 304 bartRcppU.cpp\n\n");
//            x[j+k*p] = ugrid[uix];
//            */
//            
//            for(size_t uu=0; uu<logpr.size(); ++uu) {
//              double lo = xi[j][ucutsv[uu]];
//              double up = xi[j][ucutsv[uu+1]]; 
//              x[j+k*p] = 0.5*(up+lo);
//              double newfit = f + fit_i(k, using_u, xi, di);
//              logpr[uu] = -0.5*pow((y[k] - newfit)/pi.sigma, 2) + log(up-lo);
//            }
//            int uix = rdisc_log_inplace(logpr);
//            //stop("line 304 bartRcppU.cpp\n\n");
//            x[j+k*p] = R::runif(xi[j][ucutsv[uix]], xi[j][ucutsv[uix+1]]);//ugrid[uix];
//            
//          } else {
//          }
//          
//          //update counts with new u
//          for(size_t tt=0; tt<using_u.size(); ++tt) {
//            //update_counts(k, leaf_counts[tt], using_u[tt], xi, di, bnvs[tt], 1);
//            update_counts(k, leaf_counts[tt], using_u[tt], xi, di, bnmaps[tt], 1);
//          }
//          allfit[k] = f + fit_i(k, using_u, xi, di); //should save these in previous for loop
//        }
//      }
//    }
//    /*
//    Rcout << "leaf ct diffs: ";
//    for(size_t mm=0; mm<using_u.size(); ++mm) {
//      std::vector<int> tmpv = counts(using_u[mm],  xi,  di, bnv);
//      for(size_t tt = 0; tt<leaf_counts[mm].size(); ++tt) {
//        Rcout << leaf_counts[mm][tt] - tmpv[tt] << " ";
//      }
//    }
//    Rcout << endl;
//    */
//    rss=0.0;
//    for(size_t k=0;k<n;k++) {restemp=y[k]-allfit[k]; rss += restemp*restemp;}
//    //Rcout << rss << endl;
//    pi.sigma = sqrt((nu*lambda + rss)/gen.chi_square(nu+n));
//    //if(i< (burn-2000000)) { pi.sigma = fix_sigma; }
//    
//    /*
//    for(size_t j=0;j<m;j++) {
//       fit(t[j],xi,di,ftemp);
//       for(size_t k=0;k<n;k++) allfit[k] += ftemp[k];
//    }
//    */
//    
//    if(i>=burn) {
//      ssigma(i-burn) = pi.sigma;
//       for(size_t k=0;k<n;k++) {
//         pmean[k] += allfit[k];
//         sfit(i-burn, k) = allfit[k];
//       }
//       if(dip.n) {
//         for(size_t k=0;k<dip.n;k++) {
//           if(num_u==0 | fix_pred_u==1) {
//             spred2(i-burn, k) = fit_i(k, t, xi, dip); //tested good
//           } else {
//             spred2(i-burn, k) = 0.0;
//             /*
//             double h = xi[0][1] - xi[0][0];
//             for(size_t s=1; s<xi[0].size(); ++s) {
//               xp[k*p] = 0.5*(xi[0][s] - xi[0][s-1]);
//               spred2(i-burn, k) += h*fit_i(k, t, xi, dip);
//             }
//             */
//           }
//         }
//       }
//    }
//  }
//  int time2 = time(&tp);
//  Rcout << "time for loop: " << time2-time1 << endl;
//  
//  for(size_t k=0;k<n;k++) pmean[k] /= (double)nd;
//
//  NumericVector bfit(n);
//  for(size_t i=0;i<n;i++) bfit[i] = pmean[i];
//  
//  NumericVector bpred(dip.n);
//  for(size_t i=0;i<dip.n;i++) bpred[i] = ppredmean[i]/= (double)nd;
//  
//  for(size_t j=0;j<using_u.size();j++) Rcout << using_u[j] << endl;  //all the trees
//  //for(size_t j=0;j<t.size();j++) Rcout << t[j] << endl; 
//  
//  //Rcout << t[2];
//  t.clear();
//  delete[] allfit;
//  delete[] r;
//  delete[] ftemp;
//  delete[] pmean;
//  delete[] ppredmean;
//  delete[] fpredtemp;
//
//  return(List::create(_["insample"] = bfit, _["pred"] = bpred, _["sigma"] = ssigma,
//                      _["postfit"] = sfit, _["postpred"] = spred, _["postpred_test"] = spred2));
//}
