#include <Rcpp.h>

#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>

#include "rng.h"
#include "tree.h"
#include "info.h"
#include "funs.h"
#include "bd.h"



using namespace Rcpp;

// [[Rcpp::export]]
List BCF_cts(NumericVector y_, //outcome
                       NumericVector ghat_, //propensity function
                       NumericVector z_, // treatment
                       NumericVector x_, // m covariates
                       NumericVector xhet_, // b covariates
                       NumericVector xz_, // h covariates
                       List xinfo_list,
                       List xhetinfo_list,
                       List xzinfo_list,
                       int kint,
                       double shatz,
                       int burn, int nd, 
                       int m_mu, int m_B, int m_h,
                       double lambda_mu, double nu_mu, double kfac_mu,
                       double lambda_B, double nu_B, double kfac_B,
                       double lambda_h, double nu_h, double kfac_h, 
                       CharacterVector treef_mu_name_,
                       CharacterVector treef_B_name_,
                       CharacterVector treef_h_name_,
                       bool save_trees = false,
                       bool b_hyperprior = true,
                       bool marginal_z = true,
                       int status_interval = 100)
{
  
  std::vector<double> bscale(kint,1.0);
  
  if(b_hyperprior) {
    Rcout << "Using prior on the variance of b" << endl;
  }
  
  /*
  std::string treef_name = as<std::string>(treef_name_); 
  std::ofstream treef(treef_name.c_str());
  
  //begin hetero
  treef_name = as<std::string>(treef_prec_name_); 
  std::ofstream treefprec(treef_name.c_str());  
  //end hetero
  */
  
  std::string treef_mu_name = as<std::string>(treef_mu_name_); 
  std::ofstream treef_mu(treef_mu_name.c_str());
  
  std::string treef_B_name = as<std::string>(treef_B_name_); 
  std::ofstream treef_B(treef_B_name.c_str());
  
  
  std::string treef_h_name = as<std::string>(treef_h_name_); 
  std::ofstream treef_h(treef_h_name.c_str());
  
  
  RNGScope scope;  
  RNG gen; //this one random number generator is used in all draws
  
  //double lambda = 1.0; //this one really needs to be set
  //double nu = 3.0;
  //double kfac=2.0; //original is 2.0
  
  Rcout << "\n*****Into bart main\n";
  
  /*****************************************************************************
  / Read, format y
  *****************************************************************************/
  std::vector<double> y; //storage for y
  double miny = INFINITY, maxy = -INFINITY;
  sinfo allys;       //sufficient stats for all of y, use to initialize the bart trees.
  
  for(NumericVector::iterator it=y_.begin(); it!=y_.end(); ++it) {
    y.push_back(*it);
    if(*it<miny) miny=*it;
    if(*it>maxy) maxy=*it;
    allys.sy += *it; // sum of y
    allys.sy2 += (*it)*(*it); // sum of y^2
  }
  size_t n = y.size();
  allys.n = n;
  
  double ybar = allys.sy/n; //sample mean
  double shat = sqrt((allys.sy2-n*ybar*ybar)/(n-1)); //sample standard deviation
  
  /*****************************************************************************
  / Read, format z
  *****************************************************************************/
  std::vector<double> z; //storage for z
  double minz = INFINITY, maxz = -INFINITY;
  sinfo allzs;       
  
  for(NumericVector::iterator it=z_.begin(); it!=z_.end(); ++it) {
    z.push_back(*it);
    if(*it<minz) minz=*it;
    if(*it>maxz) maxz=*it;
    allzs.sy += *it; 
    allzs.sy2 += (*it)*(*it);
  }
  allzs.n = n;
  
  double zbar = allzs.sy/n; //sample mean
  // double shatz = sqrt((allzs.sy2-n*zbar*zbar)/(n-1)); //sample standard deviation
  
  /*****************************************************************************
  / Read, format X
  *****************************************************************************/
  //read x   
  //the n*p numbers for x are stored as the p for first obs, then p for second, and so on.
  std::vector<double> x;
  for(NumericVector::iterator it=x_.begin(); it!= x_.end(); ++it) {
    x.push_back(*it);
  }
  size_t p = x.size()/n;
  
  Rcout <<"\nburn,nd,number of trees: " << burn << ", " << nd << ", " << endl;
  //Rcout <<"\nlambda,nu,kfac: " << lambda << ", " << nu << ", " << kfac << endl;
  
  //x cutpoints
  xinfo xi;
  
  xi.resize(p);
  for(int i=0; i<p; ++i) {
    NumericVector tmp = xinfo_list[i];
    std::vector<double> tmp2;
    for(size_t j=0; j<tmp.size(); ++j) {
      tmp2.push_back(tmp[j]);
    }
    xi[i] = tmp2;
  }
  
  //read xhet
  std::vector<double> xhet;
  for(NumericVector::iterator it=xhet_.begin(); it!= xhet_.end(); ++it) {
    xhet.push_back(*it);
  }
  size_t phet = xhet.size()/n;
  Rcout << phet << endl;
  //Rcout <<"\nlambda,nu,kfac: " << lambda << ", " << nu << ", " << kfac << endl;
  
  //xhet cutpoints
  xinfo xheti;
  
  xheti.resize(phet);
  for(int i=0; i<phet; ++i) {
    NumericVector tmp = xhetinfo_list[i];
    std::vector<double> tmp2;
    for(size_t j=0; j<tmp.size(); ++j) {
      tmp2.push_back(tmp[j]);
    }
    xheti[i] = tmp2;
  }
  
  
  //read xz
  std::vector<double> xz;
  for(NumericVector::iterator it=xz_.begin(); it!= xz_.end(); ++it) {
    xz.push_back(*it);
  }
  size_t pz = xz.size()/n;
  
  //xz cutpoints
  xinfo xzi;
  
  xzi.resize(pz);
  for(int i=0; i<pz; ++i) {
    NumericVector tmp = xzinfo_list[i];
    std::vector<double> tmp2;
    for(size_t j=0; j<tmp.size(); ++j) {
      tmp2.push_back(tmp[j]);
    }
    xzi[i] = tmp2;
  }
  
  
  //prxi(xi);
  
  
  //size_t nc=100; //100 equally spaced cutpoints from min to max.
  //makexinfo(p,n,&x[0],xi,nc);
  
  /*****************************************************************************
  /* Setup for MCMC
  *****************************************************************************/
  //--------------------------------------------------
  //trees
  std::vector<tree> t_mu(m_mu);
  for(size_t i=0;i<m_mu;i++) t_mu[i].setm(ybar/m_mu); //if you sum the fit over the trees you get the fit.
  
  
  // this is an array of tree objects, one forest of size m_B for each polynomial term up to kint terms
  std::vector<std::vector<tree> > t_B(kint, std::vector<tree> (m_B));
  for(size_t i=0;i<m_B;i++) {
    for(size_t j=0; j<kint; j++) {
      t_B[j][i].setm(0); //if you sum the fit over the trees you get the fit.
    }
  }
  
  
  
  std:vector<double> polyfit(n,0.);
  
  std::vector<tree> t_h(m_h);
  for(size_t i=0;i<m_h;i++) t_h[i].setm(0.); //if you sum the fit over the trees you get the fit.
  
  
  
  //--------------------------------------------------
  //prior and mcmc
  pinfo pi_mu;
  pi_mu.pbd = 1; //prob of birth/death move
  pi_mu.pb = .5; //prob of birth given  birth/death
  
  pi_mu.alpha = .95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
  pi_mu.beta = 2.0; //2 for bart means it is harder to build big trees.
  pi_mu.tau = (maxy-miny)/(2*kfac_mu*sqrt((double)m_mu)); //sigma_mu
  pi_mu.sigma = shat;
  
  pinfo pi_B;
  pi_B.pbd = 1; //prob of birth/death move
  pi_B.pb = .5; //prob of birth given  birth/death
  
  pi_B.alpha = .95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
  pi_B.beta = 2; //2 for bart means it is harder to build big trees.
  double b_tau = 1.0/(2*kfac_B*sqrt((double)m_B));
  pi_B.tau = b_tau; //sigma_mu, will be scaled by sigma_z (pi_g.sigma)
  pi_B.sigma = 1.0; //shouldn't ever get used.
  
  pinfo pi_h;
  pi_h.pbd = 1; //prob of birth/death move
  pi_h.pb = .5; //prob of birth given  birth/death
  
  pi_h.alpha = .95; //prior prob a bot node splits is alpha/(1+d)^beta, d is depth of node
  pi_h.beta = 2.0; //2 for bart means it is harder to build big trees.
  pi_h.tau = (maxz-minz)/(2*kfac_h*sqrt((double)m_h)); //sigma_mu - unused
  pi_h.sigma = pi_mu.sigma;// This *has* to be set to sigma_y (pi_mu.sigma) on each update
  
  pi_B.tau = b_tau*shatz;
  
  
  
  
  //   
  //   Rcout << "\nalpha, beta: " << pi.alpha << ", " << pi.beta << endl;
  //   Rcout << "sigma, tau: " << pi.sigma << ", " << pi.tau << endl;
  //   
  
  //--------------------------------------------------
  //dinfo
  double* allfit_mu = new double[n]; //sum of fit of all trees
  for(size_t i=0;i<n;i++) allfit_mu[i] = ybar;
  double* r_mu = new double[n]; //y-(allfit_mu-ftemp) = y-allfit_mu+ftemp
  double* ftemp_mu = new double[n]; //fit of current tree
  dinfo di_mu;
  di_mu.n=n; di_mu.p=p; di_mu.x = &x[0]; 
  di_mu.y=r_mu; //the y for each draw will be the residual 
  
  
  
  std::vector<std::vector<double> > allfit_B(kint, std::vector<double> (n));
  for(size_t i=0;i<n;i++) {
    for(size_t j=0; j<kint; j++) {
      allfit_B[j][i]  = 0.0; //if you sum the fit over the trees you get the fit.
    }
  }
  
  
  //  double* allfit_B = new double[n]; //sum of fit of all trees
  //  for(size_t i=0;i<n;i++) allfit_B[i] = 0;
  double* r_B = new double[n]; //y-(allfit_B-ftemp) = y-allfit_B+ftemp
  double* ftemp_B = new double[n]; //fit of current tree
  dinfo di_B;
  di_B.n=n; di_B.p=p; di_B.x = &x[0]; 
  di_B.y=r_B; //the y for each draw will be the residual 
  
  
  
  double* allfit_g = new double[n]; //container for selection model preds
  for(size_t i=0;i<n;i++) allfit_g[i] = ghat_[i];

  double* allfit_h = new double[n]; //fits for h(z)
  for(size_t i=0;i<n;i++) allfit_h[i] = 0.;
  
  double* r_h = new double[n]; //y-(allfit_g-ftemp) = y-allfit_g+ftemp
  double* ftemp_h = new double[n]; //fit of current tree
  dinfo di_h;
  di_h.n=n; di_h.p=pz; di_h.x = &xz[0]; 
  di_h.y=r_h; //the y for each draw will be the residual 
  
  double* precs = new double[n]; // temp storage for conditional ''precisions''
  
  double rss_z, rss_y, restemp_z, restemp_y;
  
  NumericVector ssigma_z(nd);
  NumericVector ssigma_y(nd);
  NumericMatrix sfit_mu(nd,n);
  NumericMatrix sfit_B(nd,n);
  NumericMatrix sfit_h(nd,n);
  //NumericMatrix spred2(nd,dip.n);
  
  int thin = 1;
  //save stuff to tree file
  treef_mu << xi << endl; //cutpoints
  treef_mu << m_mu << endl;  //number of trees
  treef_mu << p << endl;  //dimension of x's
  treef_mu << (int)(nd/thin) << endl;
  
  treef_B << xi << endl; //cutpoints
  treef_B << m_B << endl;  //number of trees
  treef_B << p << endl;  //dimension of x's
  treef_B << (int)(nd/thin) << endl;
  
  
  
  // treef_h << xi << endl; //cutpoints
  //	treef_h << m_g << endl;  //number of trees
  //	treef_h << p << endl;  //dimension of x's
  //	treef_h << (int)(nd/thin) << endl;
  
  Rcout << "\nMCMC:\n";
  time_t tp;
  int time1 = time(&tp);
  
  std::vector<double> response_trans(n); //Transformed ``response'' variable
  
  for(int k=0; k<n; ++k) {
    for (int j=0; j<kint; ++j) {
      polyfit[k] += bscale[j]*allfit_B[j][k]*pow(z[k] - allfit_g[k],j+1);
    }
  }
  
/*****************************************************************************
* MCMC
*****************************************************************************/
  
  for(size_t i=0;i<(nd+burn);i++) {
    
    Rcpp::checkUserInterrupt();
    
    if(i%status_interval==0) Rcpp::Rcout << "i: " << i << " sigma_y: "<< pi_mu.sigma << " sigma_z: "<< shatz << endl;
    
    //Sample mu
    for(size_t k=0; k<n; ++k) {
      response_trans[k] = y[k] - polyfit[k] - allfit_h[k];
    }
    
    for(size_t j=0;j<m_mu;j++) {
      fit(t_mu[j],xi,di_mu,ftemp_mu);
      for(size_t k=0;k<n;k++) {
        if(ftemp_mu[k] != ftemp_mu[k]) {
          Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
          Rcout << t_mu[j] << endl;
          stop("nan in ftemp");
        }
        allfit_mu[k] = allfit_mu[k] - ftemp_mu[k];
        r_mu[k] = response_trans[k] - allfit_mu[k];
      }
      
      // bd(t_mu[j],xi,di_mu,pi_mu,gen); 
      /*
      if(gen.uniform()>pi_mu.pbd) {
        tree::tree_p tnew;
        tnew=new tree(t_mu[j]); //copy of current to make life easier upon rejection
        rotp(tnew,t_mu[j],xi,di_mu,pi_mu,gen);
        delete tnew;
      } else {
       */
        bd(t_mu[j],xi,di_mu,pi_mu,gen); 
      //}
      
      drmu(t_mu[j],xi,di_mu,pi_mu,gen);
      fit(t_mu[j],xi,di_mu,ftemp_mu);
      for(size_t k=0;k<n;k++) allfit_mu[k] += ftemp_mu[k];
    }

    //Sample h
    for(size_t k=0; k<n; ++k) {
      response_trans[k] = y[k] - polyfit[k] - allfit_mu[k];
    }
    
    for(size_t j=0;j<m_h;j++) {
      fit(t_h[j],xzi,di_h,ftemp_h);
      for(size_t k=0;k<n;k++) {
        if(ftemp_h[k] != ftemp_h[k]) {
          Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
          Rcout << t_h[j] << endl;
          stop("nan in ftemp");
        }
        allfit_h[k] = allfit_h[k] - ftemp_h[k];
        r_h[k] = response_trans[k] - allfit_h[k];
      }
      
      // bd(t_h[j],xzi,di_h,pi_h,gen); 
      /*
      if(gen.uniform()>pi_h.pbd) {
        tree::tree_p tnew;
        tnew=new tree(t_h[j]); //copy of current to make life easier upon rejection
        rotp(tnew,t_h[j],xzi,di_h,pi_h,gen);
        delete tnew;
      } else { */
        bd(t_h[j],xzi,di_h,pi_h,gen); 
      //}
      
      drmu(t_h[j],xzi,di_h,pi_h,gen);
      fit(t_h[j],xzi,di_h,ftemp_h);
      for(size_t k=0;k<n;k++) allfit_h[k] += ftemp_h[k];
    }
    
    // sample B
    for(size_t h=0; h<kint; h++){
      if (i>=0.0*burn) {
        for(size_t k=0; k<n; ++k) {
          double eps_z = bscale[h]*pow(z[k] - allfit_g[k],h+1);
          response_trans[k] = (y[k] - allfit_mu[k] - allfit_h[k] - polyfit[k] + allfit_B[h][k]*eps_z)/eps_z;
          precs[k] = eps_z*eps_z/((pi_mu.sigma)*(pi_mu.sigma));
        }
        
        for(size_t j=0;j<m_B;j++) {
          fit(t_B[h][j],xheti,di_B,ftemp_B);
          for(size_t k=0;k<n;k++) {
            if(ftemp_B[k] != ftemp_B[k]) {
              Rcout << "tree " << j <<" obs "<< k<<" "<< endl;
              Rcout << t_B[h][j] << endl;
              stop("nan in ftemp");
            }
            allfit_B[h][k] = allfit_B[h][k] - ftemp_B[k];
            double eps_z = bscale[h]*pow(z[k] - allfit_g[k],h+1);
            r_B[k] = response_trans[k] - allfit_B[h][k];
            polyfit[k] -= ftemp_B[k]*eps_z;
          }  
          
          
          //bdhet(t_B[j],xi,di_B,precs,pi_B,gen); 
          /*
          if(gen.uniform()>pi_B.pbd) {
            tree::tree_p tnew;
            tnew=new tree(t_B[h][j]); //copy of current to make life easier upon rejection
            rotphet(tnew,t_B[h][j],xheti,di_B,precs,pi_B,gen);
            delete tnew;
          } else {*/
            bdhet(t_B[h][j],xheti,di_B,precs,pi_B,gen);
          //}
          
          drmuhet(t_B[h][j],xheti,di_B,precs,pi_B,gen);
          fit(t_B[h][j],xheti,di_B,ftemp_B);
          for(size_t k=0;k<n;k++) {allfit_B[h][k] += ftemp_B[k];
            double eps_z = bscale[h]*pow(z[k] - allfit_g[k],h+1);
            polyfit[k] += ftemp_B[k]*eps_z;
          }
        }
      }
    }
    
    //draw sigmas
    rss_y = 0.0;
    rss_z = 0.0;
    for(size_t k=0;k<n;k++) {
      //restemp_z = z[k]-allfit_g[k]; 
      //rss_z += restemp_z*restemp_z;
      restemp_y = y[k] - allfit_mu[k] - allfit_h[k] - polyfit[k];
      rss_y += restemp_y*restemp_y;
    }
    
    //update sigma_y
    pi_mu.sigma = sqrt((nu_mu*lambda_mu + rss_y)/gen.chi_square(nu_mu+n));
    pi_h.sigma = pi_mu.sigma;
    
    //update bscale
    // define q_i = (y_i - m(x_i))/(b(x)*(z-g(x))) ~ N(bscale, sigma^2_z/phi_i)
    // with 1/phi_i = 1/(b^2(x)*(z-g(x))^2)
    // this is lazy but notationally convenient
    
    if(b_hyperprior) {
      double qbar = 0.0;
      double sumphi = 0.0;
      for(size_t h=0;h<kint;h++){
        for(size_t k=0;k<n;k++) {
          double bres = allfit_B[h][k]*pow(z[k] - allfit_g[k],h+1);
          double q = (y[k] - allfit_mu[k] - allfit_h[k] - polyfit[k] + bscale[h]*allfit_B[h][k]*pow(z[k] - allfit_g[k],h+1))/bres;
          double phi = bres*bres;
          qbar += phi*q;
          sumphi += phi;
        }
        double s2z = shatz*shatz; //(pi_g.sigma*pi_g.sigma);
        qbar /= s2z;
        sumphi /= s2z;
        
        
        bscale[h] = qbar/(1 + sumphi) + sqrt(1/(1 + sumphi))*gen.normal(0,1);
        
      }
    }
    
    if(i>=burn) {
      // for(size_t j=0;j<m_mu;j++) treef_mu << t_mu[j] << endl;
      //  for(size_t j=0;j<m_B;j++) treef_B << t_B[j] << endl;
      //  for(size_t j=0;j<m_g;j++) treef_h << t_g[j] << endl;
      
      ssigma_y(i-burn) = pi_mu.sigma;
      ssigma_z(i-burn) = shatz; //toclean //pi_g.sigma;
      for(size_t k=0;k<n;k++) {
        //pmean[k] += allfit[k];
        sfit_mu(i-burn, k) = allfit_mu[k];
        sfit_B(i-burn, k) = polyfit[k];
        sfit_h(i-burn, k) = allfit_h[k];
        //       sfit_g(i-burn, k) = allfit_g[k];
      }
      //       if(dip.n) {
      //         for(size_t k=0;k<dip.n;k++) {
      //           spred2(i-burn, k) = fit_i(k, t, xi, dip); //tested good
      //           //spred2prec(i-burn, k) = fit_i(k, tprec, xiprec,/ dipprec);
      //         }
      //       }
    }
  }
  int time2 = time(&tp);
  Rcout << "time for loop: " << time2 - time1 << endl;
  
  //NumericVector bfit(n);
  //for(size_t i=0;i<n;i++) bfit[i] = pmean[i]/ (double)nd;
  
  //NumericVector bpred(dip.n);
  //for(size_t i=0;i<dip.n;i++) bpred[i] = ppredmean[i]/ (double)nd;
  /*
  t_mu.clear();
  delete[] allfit_mu;
  delete[] r_mu;
  delete[] ftemp_mu;
  t_B.clear();
  delete[] allfit_B;
  delete[] r_B;
  delete[] ftemp_B;
  
  t_B0.clear();
  delete[] allfit_B0;
  delete[] r_B0;
  delete[] ftemp_B0;
  
  t_g.clear();
  delete[] allfit_g;
  delete[] r_g;
  delete[] ftemp_g;
  //delete[] pmean;
  //delete[] ppredmean;
  //delete[] fpredtemp;
  
  */
  
  treef_mu.close();
  treef_h.close();
  treef_B.close();
  
  
  return(List::create(_["sigma_y"] = ssigma_y,
                      _["sigma_z"] = ssigma_z,
                      _["post_mu"] = sfit_mu, 
                      _["post_h"] = sfit_h, 
                      _["post_B"] = sfit_B
                        //_["postpred"] = spred, 
                        //                      _["postprecfit"] = sfitprec
  ));
  
}
