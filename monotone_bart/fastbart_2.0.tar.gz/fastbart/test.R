library(mvbart)
set.seed(4)
n = 150
x1 = as.numeric(runif(n)>0.6)
x2 = sample(3, n, replace=T)-1
Ey = x1 - 1*x2 + 3*x1*x2
y = Ey + rnorm(n, 0, .25)
m = mean(y)
y = y-m

cx = c(2,3)

X = data.frame(cbind(x1, x2))
X[,2] = factor(X[,2])
library(BayesTree)
X=makeind(X)

X = cbind(x1, x2)

X = make_ind(cbind(x1, x2), cx, c(2,3))
# 
# List bartRcpp(NumericVector y_, NumericVector x_, NumericVector xpred_, 
#               IntegerVector cx, IntegerVector x_type, IntegerMatrix lookup_table,
#               IntegerMatrix x_mask, IntegerMatrix x_cat,
#               int seed=99)

pp = rbind(X[1,],X[1,],X[1,])
pp[1,2]=1; pp[1,3]=0
pp[3,4]=1; pp[3,3]=0

Xmask = 0*as.matrix(cbind(x1, x2))
Xmask[2,1] = 1
Xmask[1,2] = 1
fit = bartRcpp(y, t(X), xpred=t(pp),
               cx, c(2, 3), as.matrix(make_lookup_ind(cx, c(2,3))-1),
               Xmask, as.matrix(cbind(x1, x2)),
               2)
hist(fit$testimp)
print(fit$pred)