library(fastbart)
library(rpart.plot)
set.seed(12)

n = 1500
p = 5

sigma_z = 0.1
sigma_y = 0.1

x = matrix(rnorm(n*p), ncol=p)

g = function(x) -0.5*x[,1]^2 + x%*%rep(1/sqrt(p), p)
b = function(x) (1+(x[,2]>0))
m = function(x) -1 + 2*x[,1] 
phi = function(z) (atan(z)+pi/2 + 1)
hg = function(x) -g(x)

ztemp = g(x) 
zmean = scale(ztemp,scale=diff(range(ztemp)))
z = zmean + sigma_z*rnorm(n) 
z = z*5
zmean = 5*zmean
y = m(x) + hg(x) + b(x)*phi(z) + sigma_y*rnorm(n)
y = y - mean(y)

# Setting priors
sighat = 0.0000001 #sd(y) #summary(lmf)$sigma
nu = 3
sigq = .9
qchi = qchisq(1.0-sigq,nu)
lambda = (sighat*sighat*qchi)/nu 

# Setting possible of cutpoint locations 
cp_uniform  = function(x, num=10000) seq(min(x), max(x), length.out=num)
cp_quantile = function(x, num=10000) quantile(x, p=(0:num)/num)


# Make sure this points somplace that exists!
dir = path.expand('~/Dropbox/tmp/')

cutpoint_list = lapply(1:ncol(x), function(i) cp_quantile(x[,i]))

### Estimating ghat

fitg = bartRcppClean(y_ = z, x_ = t(x),xpred_ = t(x),
                     cutpoint_list,burn = 500,nd=1500,
                     m =100,lambda = 1, nu = 1, kfac = 1, 
                     treef_name_ = paste0(dir,"gtrees.txt"),
                     chgmat = matrix(0,1,1))

ghat = fitg$insample
ghat = ghat
ghat_not0 = ghat 

# Define three sets of covariates: x, xhet, and xz
# model: y = m(x) + h(xz) + \sum_j b_j(xhet)z^j + eps

x = matrix(x, dim(x))
cutpoint_list_x = lapply(1:ncol(x), function(i) cp_quantile(x[,i]))

xhet = matrix(x, dim(x))
cutpoint_list0 = lapply(1:ncol(xhet),function(i) cp_quantile(as.matrix(xhet)[,i]))

xz = matrix(ghat_not0, ncol=1)
cutpoint_list_xz = lapply(1,function(i) cp_quantile(as.matrix(xz)[,i]))

fit = BCF_cts(y_=y, ghat_ = ghat, z_=z, x_=t(x), xhet_=t(xhet), xz_ = t(xz),
                        cutpoint_list, cutpoint_list0, cutpoint_list_xz,
                        kint = 4,
                        shatz = sigma_z,
                        burn=3000, nd=3000, # burnin/number of draws
                        m_mu = 50, m_B = 50, m_h = 50, #no. of trees
                        lambda_mu = lambda, lambda_B = lambda, lambda_h = lambda, # this is dumb but OK for now
                        nu_mu = nu, nu_B = nu, nu_h = nu, # same
                        kfac_mu = 1, kfac_B = 1, kfac_h = 1, # need easier way to specify variance of each fcn
                        treef_mu_name_ = paste0(dir,"mu.txt"),
                        treef_B_name_  = paste0(dir,"B.txt"),
                        treef_h_name_  = paste0(dir,"g.txt")
)

library(coda)

plot(mcmc(data.frame(sigma_y=fit$sigma_y)))

muhat = colMeans(fit$post_mu)
polyfit  = colMeans(fit$post_B)

plot(z, polyfit, col=as.numeric(factor(b(x))))

par(mfrow=c(1,2))
plot(m(x)+hg(x),muhat,pch=20)
plot(b(x)*phi(z),polyfit,pch=20)

# abline(0,1,col='red')

plot(muhat,b(x)*atan(z)-polyfit,pch=20)
ind = x[,2]>0
points(muhat[ind],b(x[ind,])*atan(z[ind]) - polyfit[ind],pch=20,col='red')
abline(0,1)


ind = as.numeric(x[,2]>0)+1
par(mfrow=c(1,2))
# polyfit looks wrong in the uncentered model; why??
plot(z,(atan(z)+1+pi/2) - mean(b(x)*(atan(z)+1+pi/2)), ylim=c(-10, 10), col=c('orange', 'darkgreen')[ind])
#points(z,polyfit-mean(polyfit),pch=20,col='orange',cex=0.5)
points(z,polyfit-mean(polyfit),pch=20,col=c('orange', 'darkgreen')[ind],cex=0.5)

plot(z,b(x)*(atan(z)+1+pi/2) - mean(b(x)*(atan(z)+1+pi/2)), ylim=c(-10, 10), col=c('orange', 'darkgreen')[ind])
points(z,polyfit-mean(polyfit),pch=20,col=c('orange', 'darkgreen')[ind],cex=0.5)

par(mfrow=c(1,1))
plot(x[,1],m(x) - muhat)
points(x[,1],b(x)*atan(z) - polyfit,col='red')

