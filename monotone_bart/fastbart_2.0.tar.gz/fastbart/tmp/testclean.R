library(fastbart)
set.seed(705)
n = 400
dir = path.expand("~/Desktop")

x = runif(n)
x2 = as.numeric(runif(n)>0.5)
y = 3*x + (2-3*x2)*sin(pi*x) - 2*x2 + rnorm(n, 0, .7) 
ybar = 0#mean(y)
y = y-ybar


# Calibrate BART's error variance a la CGM 2010
df = data.frame(x, x2, y)
lmf = lm(y~.,df)
sighat = sigma(lmf) #sd(y) #summary(lmf)$sigma

nu = 3
sigq = .9
qchi = qchisq(1.0-sigq,nu)
lambda = (sighat*sighat*qchi)/nu 


# Design matrix
xx = cbind(x, x2)

# Where to generate predictions
xpred = cbind( rep((1:99)/100, 2), c(rep(0, 99), c(rep(1,99))))

cutpoints = list((1:9999)/10000, c(0, 0.5, 1))

set.seed(1)
fit = bartRcppClean(y, t(xx), # obsvervations must be in *columns*
                       t(xpred), #Dpred,#[,-2,drop=F],
                       cutpoints, 
                       1000, 1000, 200, 
                       lambda, nu, 2, 
                       paste0(dir,"/test2.txt"),
                       RJ=FALSE
)

# Load posterior samples of the trees & generate predictions
ts = TreeSamples$new()
ts$load(paste0(dir,'/test2.txt'))
insam = ts$predict(t(xx))
pred = ts$predict(t(xpred))

# plot(apply(fit.rj$postfit[(nrow(fit.rj$postfit)-1000):nrow(fit.rj$postfit),], 2, sd), apply(fit$postfit, 2, sd))
# 
# plot(fit$sigma, type='l')
# lines(fit.rj$sigma, col='red')
# plot(density(fit$sigma))
# lines(density(fit.rj$sigma), col='red')
# 
# pairs(cbind(y, colMeans(fit.rj$postfit), colMeans(fit$postfit)))
# cor(cbind(y, colMeans(fit.rj$postfit), colMeans(fit$postfit)))



stop()

#plot((1:99)/100, ybar+colMeans(fit$postpred), type='l')

library(dbarts)

fit.old = bart(xx, y, x.test = xpred, sigest=sighat, nskip=1000)

plot(density((fit.old$sigma)))
lines(density((fit$sigma)), col='red')

plot(fit.old$yhat.test.mean, colMeans(pred)); abline(0,1)
hist(fit.old$yhat.test.mean - colMeans(pred))

# 
# plot((1:99)/100, fit.old$yhat.test.mean, type='l')
# lines((1:99)/100, apply(fit.old$yhat.test, 2, quantile, 0.025), lty=2)
# lines((1:99)/100, apply(fit.old$yhat.test, 2, quantile, 0.975), lty=2)
# 
# lines((1:99)/100, colMeans(fit$postpred), col='red')
# lines((1:99)/100, apply(fit$postpred, 2, quantile, 0.025), lty=2, col='red')
# lines((1:99)/100, apply(fit$postpred, 2, quantile, 0.975), lty=2, col='red')
