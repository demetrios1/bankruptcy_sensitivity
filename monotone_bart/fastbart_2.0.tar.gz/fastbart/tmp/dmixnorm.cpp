//[[Rcpp::depends(BH, RcppGSL)]]

//#include <R_ext/Applic.h>

#include <Rcpp.h>
#include <RcppGSL.h>
#include <boost/math/tools/roots.hpp>
#include <gsl/gsl_integration.h>

using namespace std;
using namespace Rcpp;

inline double logsumexp(const double &a, const double &b){
  return a < b ? b + log(1.0 + exp(a - b)) : a + log(1.0 + exp(b - a));
}

template <class T>
double logsumexp(T &x) {
  double m = *std::max_element(x.begin(), x.end());
  double s = 0.0;
  typename T::iterator it;
  for(it=x.begin(); it!=x.end(); ++it) {
    s += exp(*it-m);
  }
  return(m+log(s));
}

/*******************************************************************************
 * My version of approxfun
 ******************************************************************************/

//http://stackoverflow.com/questions/11396860/better-way-than-if-else-if-else-for-linear-interpolation
const double INF = 1.e100;
class approxfun {
  vector<pair<double, double> > table;
  public:
  double interpolate( double x);
  approxfun() {};
  approxfun(NumericVector x, NumericVector y);
  double operator()( double x) {
    return interpolate(x);
  }
};

double approxfun::interpolate( double x) {
  // Assumes that "table" is sorted by .first
  // Check if x is out of bound
  if (x > table.back().first) return INF;
  if (x < table[0].first) return -INF;
  vector<pair<double, double> >::iterator it, it2;
  // INFINITY is defined in math.h in the glibc implementation
  it = lower_bound(table.begin(), table.end(), make_pair(x, -INF));
  // Corner case
  if (it == table.begin()) return it->second;
  it2 = it;
  --it2;
  return it2->second + (it->second - it2->second)*(x - it2->first)/(it->first - it2->first);
}
approxfun::approxfun(NumericVector x, NumericVector y) {
  table.resize(x.size());
  for(size_t i=0; i<x.size(); ++i) {
    table[i] = make_pair(x(i), y(i));
  }
}


RCPP_MODULE(cpp_approxfun_mod){
    
    class_<approxfun>("cpp_approxfun" )
        .constructor<NumericVector,NumericVector>() 
        .method( "interpolate", &approxfun::interpolate )   
    ;
    
}


//[[Rcpp::export]]
NumericVector dmixnorm0(NumericVector& x, NumericVector& logprob, NumericVector& mu, double& sd) {
  NumericVector out(x.size());
  std::vector<double> tmp(logprob.size());
  for(int i=0; i<x.size(); ++i) {
    for(int h=0; h<logprob.size(); ++h) {
      tmp[h] = logprob(h) + R::dnorm(x(i), mu(h), sd, 1);
    }
    out(i) = logsumexp(tmp);
  }
  return(out);
}


//[[Rcpp::export]]
NumericVector pmixnorm0(NumericVector& x, NumericVector& logprob, NumericVector& mu, double& sd) {
  NumericVector out(x.size());
  std::vector<double> tmp(logprob.size());
  for(int i=0; i<x.size(); ++i) {
    for(int h=0; h<logprob.size(); ++h) {
      tmp[h] = logprob(h) + R::pnorm(x(i), mu(h), sd, 1, 1);
    }
    out(i) = logsumexp(tmp);
  }
  return(out);
}


//[[Rcpp::export]]
NumericVector dmixnorm0mat(NumericVector& x, NumericVector& logprob, NumericMatrix& mu, NumericVector& sd) {
  NumericMatrix out(x.size(), mu.ncol());
  std::vector<double> tmp(mu.nrow());
  
  for(int j=0; j<mu.ncol(); ++j) {
    for(int i=0; i<x.size(); ++i) {
      for(int h=0; h<logprob.size(); ++h) {
        tmp[h] = logprob(h) + R::dnorm(x(i), mu(h,j), sd(j), 1);
      }
      out(i,j) = exp(logsumexp(tmp));
    }
  }
  return(out);
}

//[[Rcpp::export]]
NumericVector dmixnorm(NumericVector& x, NumericVector& logprob, NumericVector& mu, NumericVector& sd) {
  NumericVector out(x.size());
  std::vector<double> tmp(logprob.size());
  for(int i=0; i<x.size(); ++i) {
    for(int h=0; h<logprob.size(); ++h) {
      tmp[h] = logprob(h) + R::dnorm(x(i), mu(h), sd(h), 1);
    }
    out(i) = logsumexp(tmp);
  }
  return(out);
}

//[[Rcpp::export]]
NumericVector pmixnorm(NumericVector& x, NumericVector& logprob, NumericVector& mu, NumericVector& sd) {
  NumericVector out(x.size());
  std::vector<double> tmp(logprob.size());
  for(int i=0; i<x.size(); ++i) {
    for(int h=0; h<logprob.size(); ++h) {
      tmp[h] = logprob(h) + R::pnorm(x(i), mu(h), sd(h), 1, 1);
    }
    out(i) = logsumexp(tmp);
  }
  return(out);
}

typedef std::pair<double, double> root_res;
//[[Rcpp::export]]
NumericVector qmixnorm(NumericVector& p, NumericVector& x, NumericVector& logprob, NumericVector& mu, NumericVector& sd) {
  NumericVector out(p.size());
  
  //build interpolated cdf
  NumericVector y(x.size());
  std::vector<double> tmp(logprob.size());
  for(int i=0; i<x.size(); ++i) {
    for(int h=0; h<logprob.size(); ++h) {
      tmp[h] = logprob(h) + R::pnorm(x(i), mu(h), sd(h), 1, 1);
    }
    y(i) = exp(logsumexp(tmp));
  }
  approxfun F(x, y);
  
  //find roots
  
  boost::uintmax_t max_iter = 500;
  boost::math::tools::eps_tolerance<double> tol(30);
  root_res q;
  double upper = x(x.size()-1);
  double curlower = x(0);
  for(int i=0; i<p.size(); ++i) {
    q = boost::math::tools::toms748_solve(F, curlower, upper, tol, max_iter);
    out(i) = q.first;
    curlower = q.first;
  }
  
  return(out);
}

//[[Rcpp::export]]
NumericMatrix dmixnorm0_post(NumericVector x, List mus, NumericVector sd, List logprobs) {
  NumericVector mu, logprob;
  NumericMatrix out(x.size(), mus.size());
  for(int j=0; j<mus.size(); ++j) {
    mu = as<NumericVector>(mus[j]);
    //sd = as<NumericVector>(sds[j]);
    logprob = as<NumericVector>(logprobs[j]);
    out(_,j) = dmixnorm0(x, logprob, mu, sd(j));
  }
  return out;
}

//[[Rcpp::export]]
NumericMatrix pmixnorm0_post(NumericVector x, List mus, NumericVector sd, List logprobs) {
  NumericVector mu, logprob;
  NumericMatrix out(x.size(), mus.size());
  for(int j=0; j<mus.size(); ++j) {
    mu = as<NumericVector>(mus[j]);
    //sd = as<NumericVector>(sds[j]);
    logprob = as<NumericVector>(logprobs[j]);
    out(_,j) = pmixnorm0(x, logprob, mu, sd(j));
  }
  return out;
}

//[[Rcpp::export]]
NumericMatrix pmixnorm_post(NumericVector x, List mus, List sds, List logprobs) {
  NumericVector mu, sd, logprob;
  NumericMatrix out(x.size(), mus.size());
  for(int j=0; j<mus.size(); ++j) {
    mu = as<NumericVector>(mus[j]);
    sd = as<NumericVector>(sds[j]);
    logprob = as<NumericVector>(logprobs[j]);
    out(_,j) = pmixnorm(x, logprob, mu, sd);
  }
  return out;
}
