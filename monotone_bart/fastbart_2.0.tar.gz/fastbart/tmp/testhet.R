library(fastbart)
set.seed(9250)
n=500
x = seq(0, 1, length.out = n)

g = function(x) 0.01 + 5*x^2*(x>0.2)
h = function(x) 3*x - 4*(x-0.5)^2 + 2*(x<0.3)

y = h(x) + rnorm(n, 0, sqrt(g(x)))
ybar = mean(y)
#y = y-ybar


library(MASS)

sc = 1
x = mcycle$times
y = mcycle$accel/sc

data(Boston)

y = Boston$medv
x = as.matrix(Boston[,-ncol(Boston)])

df = data.frame(x,y)
lmf = lm(y~.,df)
sighat = summary(lmf)$sigma

nu=3
sigq = .9
qchi = qchisq(1.0-sigq,nu)
lambda = (sighat*sighat*qchi)/nu 
xx = matrix(x)
xpred = xx



set.seed(120)
fit = bartRcppHeteroClean(y, t(xx), #D,#[,-2,drop=F],
                       t(xx), #Dpred,#[,-2,drop=F],
                       list(seq(min(x), max(x), length.out=1000)), 
                       list(seq(min(x), max(x), length.out=1000)), 
                       3000, 1000, 
                       200,100,
                       lambda, 0.5, 2,
                       1/lambda^2,
                       "/Users/jared/Desktop/test2.txt",
                       "/Users/jared/Desktop/test3.txt", RJ=FALSE
)

set.seed(120)
fitbart = bartRcppClean(y, t(xx), #D,#[,-2,drop=F],
                          t(xx), #Dpred,#[,-2,drop=F],
                          list(seq(min(x), max(x), length.out=100)), 
                          #list(seq(min(x), max(x), length.out=100)), 
                          1000, 1000, 
                          100,
                          lambda, 2, 2,
                          #1/sqrt(lambda),
                          "/Users/jared/Desktop/test4.txt",
                          #"/Users/jared/Desktop/test3.txt", 
                        #RJ=FALSE
)

pm = colMeans(fit$postfit)*sc
pmsd = colMeans(1/sqrt(fit$postprecfit))*sc
lo = pm-qnorm(0.95)*pmsd
hi = pm+qnorm(0.95)*pmsd
ci = apply(fit$postfit*sc, 2, quantile, c(0.05, 0.95))
matplot(x, cbind(lo, hi),
        #t(ci),
        type='l', col='black', lty=c(2,2))
lines(x, pm, type='l')
points(x, sc*y, pch=20)
stop()
pmbart = colMeans(fitbart$postfit)*sc
pmsdbart = mean(fitbart$sigma)*sc
lines(x, pmbart, type='l', col='blue')
ci = apply(fitbart$postfit*sc, 2, quantile, c(0.05, 0.95))
lines(x, pmbart-qnorm(0.95)*pmsdbart, type='l', col='blue', lty=2)
lines(x, pmbart+qnorm(0.95)*pmsdbart, type='l', col='blue', lty=2)
lines(x, ci[1,], type='l', col='blue', lty=4)
lines(x, ci[2,], type='l', col='blue', lty=4)

#curve(h(x), add=T)
#plot(x, colMeans(1/sqrt(fit$postprecfit)), type='l')
#curve(sqrt(g(x)), add=TRUE)
# 
# pmh = colMeans(fit$postfit)*10
# cih = apply(fit$postfit*10, 2, quantile, c(0.05, 0.95))
# pm = colMeans(fitbart$postfit)*10
# # pmsd = colMeans(1/sqrt(fit$postprecfit))*10
# # lo = pm-qnorm(0.95)*pmsd
# # hi = pm+qnorm(0.95)*pmsd
# ci = apply(fitbart$postfit*10, 2, quantile, c(0.05, 0.95))
# matplot(x, cbind(t(ci)), type='l', col='black', lty=c(2,2,3,3))
# lines(x, pm, type='l')
# 
# matplot(x, cbind(t(cih)), type='l', col='blue', lty=c(2,2,3,3), add=TRUE)
# lines(x, pmh, col='blue')

points(x, sc*y, pch=20)
#curve(h(x), add=T)
plot(x, colMeans(1/sqrt(fit$postprecfit)), type='l')
#curve(sqrt(g(x)), add=TRUE)

library(tgp)
out <- btgp(X=mcycle[,1], Z=mcycle[,2], bprior="b0")
matplot(x, cbind(out$Zp.mean, out$Zp.q1, out$Zp.q2), lty=c(1,2,2), col='red', type='l', add=TRUE)

stop()
plot(sqrt(g(x)), colMeans(1/sqrt(fit$postprecfit))); abline(0,1)

stop()

#ts = TreeSamples$new()
#ts$load('/Users/jared/Desktop/test.txt')
#insam = ts$predict(t(xx))

plot(apply(fit.rj$postfit[(nrow(fit.rj$postfit)-1000):nrow(fit.rj$postfit),], 2, sd), apply(fit$postfit, 2, sd))

plot(fit$sigma, type='l')
lines(fit.rj$sigma, col='red')
plot(density(fit$sigma))
lines(density(fit.rj$sigma), col='red')

pairs(cbind(y, colMeans(fit.rj$postfit), colMeans(fit$postfit)))
cor(cbind(y, colMeans(fit.rj$postfit), colMeans(fit$postfit)))



stop()

plot((1:99)/100, ybar+colMeans(fit$postpred), type='l')

library(BayesTree)

fit.old = bart(x, y, x.test=(1:99)/100, nskip=1000)

plot(density((fit.old$sigma)))
lines(density((fit$sigma)), col='red')

plot((1:99)/100, fit.old$yhat.test.mean, type='l')
lines((1:99)/100, apply(fit.old$yhat.test, 2, quantile, 0.025), lty=2)
lines((1:99)/100, apply(fit.old$yhat.test, 2, quantile, 0.975), lty=2)

lines((1:99)/100, colMeans(fit$postpred), col='red')
lines((1:99)/100, apply(fit$postpred, 2, quantile, 0.025), lty=2, col='red')
lines((1:99)/100, apply(fit$postpred, 2, quantile, 0.975), lty=2, col='red')
