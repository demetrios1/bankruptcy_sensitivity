library(fastbart)

set.seed(2)

n = 600
p = 1

sigma_z = .3
sigma_y = .1

x = matrix(rnorm(n*p), ncol=p)

g = function(x)  x[,1]-0.5*x[,1]^2
b = function(x)  1.2*sin((x[,1]-1))
m = function(x) -1 + 2*x[,1]
h = function(x)  1*atan(x)

z = g(x) + sigma_z*rnorm(n) 
#y = m(x) + b(x)*(z-g(x)) + sigma_y*rnorm(n) 
y = m(x) + (h(z) - mean(h(z))) + sigma_y*rnorm(n) 

pairs(cbind(y, x[,1], z))
# 
# par(mfrow=c(1,1))
# curve(g(x), from=-5, to=5, ylim=c(-15, 15))
# curve(b(x), add=TRUE, col='darkblue')
# curve(m(x), add=TRUE, col='darkgreen')
# curve(m(x) - b(x)*g(x), from=-3, to=3)


# Setting priors for variances based on estimate sighat
# Original BART uses a fraction of the OLS MSE to set prior
# tiny values of sighat give noninformative priors instead
# There's no need to be so informative on the error variances(?)
sighat = 0.0000001 #sd(y) #summary(lmf)$sigma
nu = 3
sigq = .9
qchi = qchisq(1.0-sigq,nu)
lambda = (sighat*sighat*qchi)/nu 

# List of cutpoint locations 
cp_uniform  = function(x, num=10000) seq(min(x), max(x), length.out=num)
cp_quantile = function(x, num=10000) quantile(x, p=(0:num)/num)

cutpoint_list = lapply(1:ncol(x), function(i) cp_uniform(x[,i]))

# Make sure this points somplace that exists!
dir = path.expand('~/Dropbox/tmp/')

fit = bartRcppLinHetTrt(y_=y, z_=z, x_=t(x), xhet_ = t(x),
                        #bartRcppLinHetTrt(y_=y, z_=z, x_=t(x),
                        cutpoint_list,
                        cutpoint_list,
                        burn=5000, nd=5000, # burnin/number of draws
                        m_mu = 100, m_B = 100, m_g = 100, #no. of trees
                        lambda_mu = lambda, lambda_B = lambda, lambda_g = lambda, # this is dumb but OK for now
                        nu_mu = nu, nu_B = nu, nu_g = nu, # same
                        kfac_mu = 1, kfac_B = 1, kfac_g = 1, # need easier way to specify variance of each fcn
                        treef_mu_name_ = paste0(dir,"mu.txt"),
                        treef_B_name_  = paste0(dir,"B.txt"),
                        treef_g_name_  = paste0(dir,"g.txt"),
                        b_hyperprior = TRUE, save_trees = FALSE
)

# 
# # Generate predictions at new x values like so
# # Not sure we need this just yet
# # make sure to supply t(xpred) or disaster (where xpred is nxp)
# mu_samples = TreeSamples$new()
# mu_samples$load("/home/jared/Desktop/mu.txt")
# mu_insample = ts$predict(t(x))

library(coda)

# These generally don't look great but I don't think
# it's a bug.
plot(mcmc(data.frame(sigma_y=fit$sigma_y, sigma_z=fit$sigma_z)))

muhat = colMeans(fit$post_mu)
bhat  = colMeans(fit$post_B)
ghat  = colMeans(fit$post_g)
somethinghat = colMeans(fit$post_mu - fit$post_B*fit$post_g)


plot(-bhat*0.1*sigma_z, h(z) - h(z+0.1*sigma_z))
abline(0,1)

# get MTE via plug-in

mte = function(z, bs, ghat, sigma_z_hat) {
  wt = dnorm(z, ghat, sigma_z_hat)
  wt = wt/sum(wt)
  #sum(wt*bhat)
  mean(colSums(t(bs)*wt))
}

zgr = seq(min(z), max(z), length.out = 1000)
hhat = sapply(zgr, function(u) mte(u, fit$post_B, ghat, mean(fit$sigma_z)))
plot(zgr[-length(zgr)], (h(zgr[-1]) - h(zgr[-length(zgr)]))/(zgr[2]-zgr[1]))
lines(zgr, hhat, ylim=h(range(z)))
rug(z)

plot(g(x), predict(loess(bhat ~ ghat)))
lines(zgr[-length(zgr)], (h(zgr[-1]) - h(zgr[-length(zgr)]))/(zgr[2]-zgr[1]))
rug(z)

hpistar = apply(t(t(fit$post_B) - predict(loess(bhat ~ ghat))), 2, quantile, c(0.05, 0.95))

plot(x[,1], bhat - predict(loess(bhat ~ ghat)))
points(x[,1], hpistar[2,], col='red')
points(x[,1], hpistar[1,], col='red')

plot(x[,1], bhat); abline(h=0)
points(x[,1], hpi[2,])
points(x[,1], hpi[1,])
points(bhat[order(bhat)])
              
par(mfrow=c(1,1))
hpi = apply(fit$post_B, 2, quantile, c(0.05, 0.95))
plot(hpi[1,order(bhat)], ylim=c(-2, 2))
abline(h=0, col='red', lwd=2)
points(hpi[2,order(bhat)])
points(bhat[order(bhat)])


par(mfrow=c(1,3))
xo = order(x[,1])
plot(x[,1], muhat); lines(x[xo,1], m(x[xo,,drop=FALSE]), lwd=2, col='red')
plot(x[,1], bhat);  lines(x[xo,1], b(x[xo,,drop=FALSE]), lwd=2, col='red')
plot(x[,1], ghat);  lines(x[xo,1], g(x[xo,,drop=FALSE]), lwd=2, col='red')
#plot(x[,1], somethinghat); curve(m(x) - b(x)*g(x), lwd=2, col='red', add=TRUE)
par(mfrow=c(1,1))
