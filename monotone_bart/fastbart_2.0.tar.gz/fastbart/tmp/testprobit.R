library(fastbart)
set.seed(881589)
n=1000
x = runif(n)
f <- function(x) 2*sin(3*pi*x)/(2*x+1) - 1
y = as.numeric((f(x) + rnorm(n, 0, 1))>0)
phat = mean(y)
offset = qnorm(phat)
z = msm::rtnorm(n, mean=0, lower = ifelse(y,-offset, -Inf), upper = ifelse(y, Inf, -offset))

set.seed(1)
fit = bartRcppProbit(y, z, x, (1:99)/100, list((1:99)/100), 100, 1000, 200, 2., offset)

plot((1:99)/100, colMeans(pnorm(offset+fit$postpred, mean=0)), type='l')
lines((1:99)/100, apply(pnorm(offset+fit$postpred), 2, function(x) quantile(x, 0.975)), type='l', lty=2)
lines((1:99)/100, apply(pnorm(offset+fit$postpred), 2, function(x) quantile(x, 0.025)), type='l', lty=2)
curve(pnorm(f(x)), add=TRUE, col='red')

#stop()
library(BayesTree)
fit.orig = bart(x, y, x.test=(1:99)/100)
lines((1:99)/100, colMeans(pnorm(fit.orig$yhat.test)), type='l', col='blue')
lines((1:99)/100, apply(pnorm(fit.orig$yhat.test), 2, function(x) quantile(x, 0.975)), type='l', lty=2, col='blue')
lines((1:99)/100, apply(pnorm(fit.orig$yhat.test), 2, function(x) quantile(x, 0.025)), type='l', lty=2, col='blue')