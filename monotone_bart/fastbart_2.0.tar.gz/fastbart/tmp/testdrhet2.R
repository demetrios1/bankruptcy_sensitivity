library(RColorBrewer)
library(fastbart)
cols = brewer.pal(8, 'Dark2')

mid = 0.8
p = function(x, h=0.1) 0.99*exp(-abs(x-mid)^2/h)
#mu0 = function(x) 12*(x-0.4)^2 - 5*exp(15*(x-0.8))/(1+exp(15*(x-0.8)))
mu0 = function(x) 5*exp(15*(x-.5))/(1+exp(15*(x-.5))) - 4*x
m1 = function(x) 1+2*(x-mid)
s1 = function(x) 0.3
a2 = function(x) 0.5+x^2
b2 = function(x) 1#0.5*exp(0.5*(x-mid))
f1 = function(y, x) dnorm(y, mu0(x) + m1(x), s1(x))
F1 = function(y, x) pnorm(y, mu0(x) + m1(x), s1(x))
f2 = function(y, x) dgamma(exp(y-mu0(x)), a2(x), b2(x))*exp(y-mu0(x))#dnorm(y, 2*sqrt(x), 2*x^2+1)
F2 = function(y, x) pgamma(exp(y-mu0(x)), a2(x), b2(x))
d = function(y, x) { p = p(x); p*f1(y, x) + (1-p)*f2(y, x) }
pp = function(y, x) { p = p(x); p*F1(y, x) + (1-p)*F2(y, x) }
r = function(x) {
  n = length(x)
  z = rbinom(n, 1, p(x))
  z*rnorm(n, m1(x), s1(x)) + (1-z)*log(rgamma(n, a2(x), b2(x))) + mu0(x)
}

#x = runif(1e5)
#plot(x, r(x))
#stop()

xgr=seq(-12, 5, length.out=10000)
uu=c(0.01, 0.99, 0.05, 0.95, 0.25, 0.75, 0.5)

gg = function(x) {
  xgr[findInterval(uu,pp(xgr, x))]
}

sgr = (1:99)/100
qp = sapply(sgr, gg)
# 
par(mar=c(5,2,2,2)+0.1)
matplot(sgr, t(qp), type='l', lty=0, col='black',
        ylab="", xlab="x", 
        #main="Quantile Process"
)
polygon(c(sgr, rev(sgr)), c(qp[1,], rev(qp[2,])),
        col = "grey90", border = NA)
polygon(c(sgr, rev(sgr)), c(qp[3,], rev(qp[4,])),
        col = "grey80", border = NA)
polygon(c(sgr, rev(sgr)), c(qp[5,], rev(qp[6,])),
        col = "grey70", border = NA)
matplot(sgr, t(qp), type='l', lty=c(0,0,0,0,0,0,1), col='black', add=TRUE, lwd=2)

# # 

#xgr=seq(-10, 5, length.out=1000)
#plot(xgr, d(xgr, 0.8), type='l')
#lines(xgr, d(xgr, 0.5))
#lines(xgr, d(xgr, 0.1))


#legend('bottomright', labels=c('IQR', '90% Int'))

lambda=1
par(mar=c(5,4,2,2)+0.1)
#x = runif(1e4)
#plot(x, r(x))

xx = c(0.1, #0.2, 0.3, 
       0.4, #0.5, 
       0.5, 
       0.6,
       #0.7, 
       0.8
       #0.9
)#(1:9)/10#c(0.1, 0.25, 0.5, 0.8, 0.95)#, 0.9)
#curve(d(x, mid), from=-5, to=5)
plot(0,0,xlim=c(-10, 4), ylim=c(0, 1.4), type='n', xlab='', ylab='')
for(i in 1:length(xx)) curve(d(x, xx[i]), add=TRUE, col=cols[i], n=1001, lwd=2)
text(c(-3,-1, 0.5, 2, 3), y=c(0.2, 0.4, 0.6, 0.9, 1.35), 
     paste("x =",xx), offset=0, pos=2, col = cols[1:length(xx)])
#stop()


set.seed(12)
n = 200
x = runif(n)
y = r(x)
#plot(x, y)

u = rep(1/2, n)
xx = cbind(u, x)
# 
fit = drbartRcppHeteroClean(y, t(xx), #D,#[,-2,drop=F],
                            t(xx), #Dpred,#[,-2,drop=F],
                            list((1:99999)/100000, (1:999)/1000), 
                            list((1:99999)/100000, (1:999)/1000), 
                            #list((1:99)/100), 
                            8000, 1000, 
                            200,100, 
                            lambda, 2, 2,
                            1, TRUE,
                            rep(0, length(y)),
                            "/Users/jared/Dropbox/drbart/fits/drex-hmean.txt",
                            "/Users/jared/Dropbox/drbart/fits/drex-hprec.txt"
)


post = function(xgr, ts, tsprec, fit, xnew) {
  
  yhat = 0# fit$postbeta%*%c(1, xnew)
  
  logprobs = lapply(fit$ucuts, function(uu) log(diff(c(0, uu, 1))))
  mids = lapply(fit$ucuts, function(uu) c(0,uu)+diff(c(0, uu, 1))/2)
  des = lapply(mids, function(mm) data.frame(mm, xnew))
  mu  = lapply(1:length(fit$ucuts), function(i)  c(ts$predict_i(t(des[[i]]), i-1)))
  phi = lapply(1:length(fit$ucuts), function(i) fit$phistar[i]*c(tsprec$predict_prec_i(t(des[[i]]), i-1)))
    #sigma = 1/sqrt(tsprec$predict_prec(matrix(xnew)))
  sigma = lapply(phi, function(x) 1/sqrt(x))
  dpost = dmixnorm_post(xgr, mu, sigma, logprobs)
  
  dpost
}


### Full model
ts = TreeSamples$new()
ts$load("/Users/jared/Dropbox/drbart/fits/drex-hmean.txt")
tsprec = TreeSamples$new()
tsprec$load("/Users/jared/Dropbox/drbart/fits/drex-hprec.txt")

xgr=seq(-12, 5, length.out=300)
#d1 = post(xgr, ts, tsprec, fit, 0.1)
d5 = post(xgr, ts, tsprec, fit, 0.1)
d8 = post(xgr, ts, tsprec, fit, 0.8)

plot(xgr, rowMeans(exp(d5)), type='l')
curve(d(x, 0.5), add=TRUE, lty=2)
lines(xgr, exp(d5)[,100])


get.mu = function(ts, fit, xnew, 
                  logprobs=NULL, mids=NULL, des=NULL) {
  if(is.null(logprobs)) logprobs = lapply(fit$ucuts, function(uu) log(diff(c(0, uu, 1))))
  if(is.null(mids)) mids = lapply(fit$ucuts, function(uu) c(0,uu)+diff(c(0, uu, 1))/2)
  if(is.null(des)) des = lapply(mids, function(mm) data.frame(mm, xnew))
  mu  = lapply(1:length(fit$ucuts), function(i) c(ts$predict_i(t(des[[i]]), i-1)))
  mu
}


get.sigma = function(tsprec, fit, xnew, 
                     logprobs=NULL, mids=NULL, des=NULL) {
  if(is.null(logprobs)) logprobs = lapply(fit$ucuts, function(uu) log(diff(c(0, uu, 1))))
  if(is.null(mids)) mids = lapply(fit$ucuts, function(uu) c(0,uu)+diff(c(0, uu, 1))/2)
  if(is.null(des)) des = lapply(mids, function(mm) data.frame(mm, xnew))
  phi = lapply(1:length(fit$ucuts), function(i) fit$phistar[i]*c(tsprec$predict_prec_i(t(des[[i]]), i-1)))
  #sigma = 1/sqrt(tsprec$predict_prec(matrix(xnew)))
  sigma = lapply(phi, function(x) 1/sqrt(x))
  
  sigma
}

xstar = 0.1 #xx[8,2]
sigma = get.sigma(tsprec, fit, xstar)
mu = get.mu(ts, fit, xstar)
mids = lapply(fit$ucuts, function(uu) c(0,uu)+diff(c(0, uu, 1))/2)
par(mfrow=c(2,1))
plot(mids[[1000]], mu[[1000]])
plot(mids[[1000]], sigma[[1000]])


mins = sapply(sigma, min)
allfits = 1/sqrt(fit$postprecfit[,8])

stop()
xstar = scores[1,1:(rcol-1)]
mu = get.mu(mutree, fit7, xstar)
mids = lapply(fit7$ucuts, function(uu) c(0,uu)+diff(c(0, uu, 1))/2)
logprobs = lapply(fit7$ucuts, function(uu) log(diff(c(0, uu, 1))))
plot(mids[[1000]], mu[[1000]], type='s')


stop()

#pdf("/Users/jared/Dropbox/drbart/paper/figures/drex-result.pdf", width=4, height=6)
par(mfrow=c(3,2), mar = c(4, 4, 1, 1) + 0.1)
plot(xgr, rowMeans(exp(d1.L)), type='l', ylim=c(0, 0.3), xlim=c(-10, 3), xlab='',ylab="DR-BART-L"); lines(xgr, d(xgr, 0.1), lty=2)
#plot(xgr, rowMeans(exp(d5.L)), type='l', ylim=c(0,1)); lines(xgr, d(xgr, 0.6), col='red')
plot(xgr, rowMeans(exp(d8.L)), type='l', ylim=c(0,1.3), xlim=c(-3,4), xlab='', ylab=''); lines(xgr, d(xgr, 0.8), lty=2)

plot(xgr, rowMeans(exp(d1.LH)), type='l', ylim=c(0, 0.3), xlim=c(-10, 3), xlab='',ylab="DR-BART-LH"); lines(xgr, d(xgr, 0.1), lty=2)
#plot(xgr, rowMeans(exp(d5.L)), type='l', ylim=c(0,1)); lines(xgr, d(xgr, 0.6), col='red')
plot(xgr, rowMeans(exp(d8.LH)), type='l', ylim=c(0,1.3), xlim=c(-3,4), xlab='', ylab=''); lines(xgr, d(xgr, 0.8), lty=2)

plot(xgr, rowMeans(exp(d1)), type='l', ylim=c(0, 0.3), xlim=c(-10, 3), xlab="x = 0.1", ylab="DR-BART"); lines(xgr, d(xgr, 0.1), lty=2)
#plot(xgr, rowMeans(exp(d5.L)), type='l', ylim=c(0,1)); lines(xgr, d(xgr, 0.6), col='red')
plot(xgr, rowMeans(exp(d8)), type='l', ylim=c(0,1.3), xlim=c(-3,4), ylab='', xlab="x = 0.8"); lines(xgr, d(xgr, 0.8), lty=2)
dev.off()


stop()






ts = TreeSamples$new()
ts$load("/Users/jared/Dropbox/drbart/fits/drex-hmean.txt")
tsprec = TreeSamples$new()
tsprec$load("/Users/jared/Dropbox/drbart/fits/drex-hprec.txt")


stop()

xnew = 0.8


#y = dmixnorm0(xgr, log(probs), mu[1000,], fit$sigma[1000])
#plot(xgr, exp(y))

plot(xgr, apply(exp(dpost), 1, mean), type='l')
#matplot(xgr, t(apply(exp(dpost), 1, quantile, c(0.05, 0.95))), lty=2, col='black', type='l', add=TRUE)
curve(d(x, xnew), add=TRUE, col = 'blue')

#plot(x, colMeans(1/sqrt(fit$postprec)))

#plot(fit$postprecfit[,1], tsprec$predict_prec(matrix(xnew)))

fhat = approxfun(xgr, rowMeans(exp(dpost)))
tt = function(x, xnew) abs(fhat(x) - d(x, xnew))
integrate(function(x) tt(x, xnew) , min(xgr), max(xgr))

#scale: 168sec, .094, .286, .250
#noscale: 143sec, .0858, 0.292, 0.458