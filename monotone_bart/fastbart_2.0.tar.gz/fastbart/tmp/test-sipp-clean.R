library(fastbart)

#sink('tmp.txt')

wd = '~/Dropbox/hcmm_imp/'
sample.size=6000
library(stringr)
filenum=10
file.prefix = paste0(wd, 'output/',sample.size, '/',str_pad(filenum, 3, pad='0'))


#if(!is.na(seed)) { set.seed(seed) } else { set.seed(4093) }

file = paste0(wd, 'data/',sample.size,'/',str_pad(filenum, 3, pad='0'), '.Rdata')
load(file)

# Process the data
dataset = complete.dataset

#for(j in 1:ncol(dataset)) {
#  dataset[is.na(mask[,j]),j] = sample(dataset[!is.na(mask[,j]),j], sum(is.na(mask[,j])), replace=T)
#}

# base test case
pix = 1098
c1 = dataset[pix,]
c2 = c3 = c4 = c1
#c2$marital_status = "Married, spouse present"
#c3$marital_status = "Married, spouse present"
c3$own_kid = 1
c4$own_kid = 1
#c4 = c3
c2$sex = "Male"
c4$sex = "Male"
c3$age = 24
c2$age = 24

dataset = rbind(dataset, c2, c3, c4)
mask = rbind(mask, mask[1,], mask[1,], mask[1,])
subs = 1:6003

X = dataset[subs,4:14]

for(i in 1:ncol(X)) X[,i] = as.integer(X[,i])
X = as.matrix(X)-1
Xmask = matrix(as.logical(mask[subs,4:14]), nrow=nrow(X))
cx = cx[4:14]

Y = as.matrix(dataset[subs,c(1,2)])

log_off = 10
Y[,1] = log(Y[,1]+log_off)

Y = scale(Y)
y.m = attr(Y, 'scaled:center')
y.s = attr(Y, 'scaled:scale')
Y = as.matrix(Y)

Ymask = matrix(as.logical(mask[subs,1:2]), nrow=nrow(Y))
# 
# // [[Rcpp::export]]
# List bartRcpp(NumericVector y_, IntegerVector ymask, NumericVector x_, NumericVector xpred_, 
#               IntegerVector cx, IntegerVector x_type, IntegerMatrix lookup_table,
#               IntegerMatrix xmask_, IntegerMatrix x_cat_,
#               int seed=99)
# 
Xd = dataset[subs,4:14]
for(v in c('own_kid', 'edu_level', 'hrs')) Xd[[v]] = as.numeric(Xd[[v]])-1

type = c(2, 3, 3, 2, 2, 
         2, 3, 3, 2, 2, 2)
XX = make_ind(X+1, cx, type)
#XX = make_ind(Xd, cx, type)
ymask = rep(0, nrow(Y))
Xmask = matrix(as.numeric(mask[subs,4:14]), nrow=nrow(Xmask))
#Xmask[,5]=0
#mask[400,11] = 1
set.seed(56)

#XXquant = apply(XX, 2, function(x) quantile(x, probs=(1:100)/101))

ta = as.matrix(make_lookup_ind(cx, type))
offsets = ta[match(1:length(cx), ta[,1]),2]-1

num_u = 1
U = matrix(runif(nrow(XX)*num_u), nrow=nrow(X))
xin = cbind(U, XX, Y[,2])
XXcut = apply(XX, 2, function(x) (sort(unique(x))+0.5)[-length(unique(x))])
Ycut = as.list(as.data.frame(apply(Y[,2,drop=FALSE], 2, function(x) quantile(x, probs=(1:100)/101))))
Ucut = ifelse(num_u==0, list(), lapply(1:num_u, function(x) (0:1000)/1000))
xinfo =  c(Ucut, XXcut, Ycut)
xinfo = xinfo[!unlist(lapply(xinfo, is.null))]

Ugrid = Ucut[[1]] - (Ucut[[1]][2] - Ucut[[1]][1])/2
Ugrid = c(Ugrid, Ugrid[length(Ugrid)] + (Ucut[[1]][2] - Ucut[[1]][1]))
Ugrid = Ugrid[2:(length(Ugrid)-1)]
if(num_u==1) {
  xpred = rbind(matrix(rep(xin[pix,], length(Ugrid)), nrow=length(Ugrid), byrow=T),
                matrix(rep(xin[6001,], length(Ugrid)), nrow=length(Ugrid), byrow=T),
                matrix(rep(xin[6002,], length(Ugrid)), nrow=length(Ugrid), byrow=T),
                matrix(rep(xin[6003,], length(Ugrid)), nrow=length(Ugrid), byrow=T))
  xpred[,1] = Ugrid
} else {
#xpred = xin[5500:6000,]
  xpred = xin[pix,]
}

subs = 2000
xin = xin[1:subs,]

fit = bartRcppU(Y[1:subs,1], ymask, t(xin), t(xpred),
         cx, type, offsets,
         Xmask, X, Ugrid, 0.3, 1000, 1000, 500, num_u, xinfo, fix_pred_u=1, status=10)
stop()

# posterior density w u
par(mfcol=c(1,1))
ml = list(
  means1 = fit$postpred_test[,1:101],
  means2 = fit$postpred_test[,102:202],
  means3 = fit$postpred_test[,203:303],
  means4 = fit$postpred_test[,304:404]
)
sd = fit$sigma

g = function(xx) rowSums(dnorm(xx, ml[[4]], sd)/101)
post.dens = sapply(seq(-3, 3, length.out=100), g)

xx = seq(-3, 3, length.out=100)*y.s[1]+y.m[1]
plot(xx, apply(post.dens, 2, quantile, 0.95), type='l', lty=2, ylim=c(0,1), xlab="Age", ylab="")
lines(xx, colMeans(post.dens), type='l')
lines(xx, apply(post.dens, 2, quantile, 0.05), lty=2)


stop()
## posterior density w/o u
means0 = fit$postpred_test
sd0 = fit$sigma
post.dens0 = sapply(seq(-3, 3, length.out=100), dnorm, mean=means0, sd=sd0)
lines(seq(-3, 3, length.out=100), apply(post.dens0, 2, quantile, 0.95), type='l', lty=2, col='blue')
lines(seq(-3, 3, length.out=100), colMeans(post.dens0), type='l', col='blue')
lines(seq(-3, 3, length.out=100), apply(post.dens0, 2, quantile, 0.05), lty=2, col='blue')

plot(apply(fit$postpred_test, 1, function(x) length(unique(x))))

colMeans(fit$postpred_test)
colMeans(fit$postfit[,1:3])
fit$insample[1:3]

#hist(fit$insample, breaks=20)
#hist(Y[,2], breaks=20)

#plot(Y[,2], fit$insample, ylim=c(-5,5)); abline(0,1)
plot(Y[1:5500,2], fit$insample, ylim=c(-5,5), col=1+as.numeric(Xd$own_kid)); abline(0,1)
plot(Y[5500:6000,2], colMeans(fit$postpred_test), ylim=c(-5,5), col=1+as.numeric(Xd$own_kid)); abline(0,1)

qplot(Y[,2] - fit$insample, color=factor(Xd$own_kid), geom='density')

fitlm = lm(Y[,2] ~ ., data=data.frame(Xd, earnings=Y[,1]))
plot(Y[,2], predict(fitlm), ylim=c(-5,5), col=1+as.numeric(Xd$own_kid)); abline(0,1)

qplot(resid(fitlm), color=factor(Xd$marital_status), geom='density')

#print(t(XX)[65869:(65869+43)])
#sink()

